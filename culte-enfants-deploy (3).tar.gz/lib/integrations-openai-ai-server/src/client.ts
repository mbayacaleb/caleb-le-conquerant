import OpenAI from "openai";

const hasReplitProxy =
  process.env.AI_INTEGRATIONS_OPENAI_BASE_URL &&
  process.env.AI_INTEGRATIONS_OPENAI_API_KEY;

const hasDirectKey = !!process.env.OPENAI_API_KEY;

if (!hasReplitProxy && !hasDirectKey) {
  throw new Error(
    "OpenAI credentials missing. Set OPENAI_API_KEY (production) or provision the Replit OpenAI AI integration (development).",
  );
}

export const openai = hasReplitProxy
  ? new OpenAI({
      apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
      baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
    })
  : new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
