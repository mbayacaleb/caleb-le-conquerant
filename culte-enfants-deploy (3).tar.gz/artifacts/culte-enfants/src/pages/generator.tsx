import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";
import { Sparkles, Save, RefreshCw, ChevronDown, ChevronUp, BookOpen, Users, Layers, AlertTriangle, CheckCircle2, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useCreateLesson, getListLessonsQueryKey, getGetLessonsStatsQueryKey } from "@workspace/api-client-react";

const formSchema = z.object({
  titre: z.string().min(2, "Le titre est requis"),
  reference: z.string().min(2, "La référence biblique est requise"),
  trancheAge: z.enum(["petits", "moyens", "grands"]),
  sequence: z.enum(["1", "2", "3", "4"]),
  contexteLecon: z.string().optional(),
});
type FormValues = z.infer<typeof formSchema>;

const SEQUENCES = [
  { value: "1", label: "Séquence 1", sub: "Installation des ressources", color: "#3b82f6", bg: "#eff6ff", border: "#bfdbfe" },
  { value: "2", label: "Séquence 2", sub: "Évaluation & intégration", color: "#16a34a", bg: "#f0fdf4", border: "#bbf7d0" },
  { value: "3", label: "Séquence 3", sub: "Vérification des intégrations", color: "#d97706", bg: "#fffbeb", border: "#fde68a" },
  { value: "4", label: "Séquence 4", sub: "Remédiation", color: "#dc2626", bg: "#fef2f2", border: "#fecaca" },
];
const AGE_GROUPS = [
  { value: "petits", label: "Petits", sub: "Maternelle – CE1", icon: "👶" },
  { value: "moyens", label: "Moyens", sub: "CE2 – CM1", icon: "🧒" },
  { value: "grands", label: "Grands", sub: "CM2 et plus", icon: "👦" },
];

type D = Record<string, unknown>;
function str(v: unknown): string { return typeof v === "string" ? v : String(v ?? ""); }
function arr<T>(v: unknown): T[] { return Array.isArray(v) ? (v as T[]) : []; }
function obj(v: unknown): D { return (v != null && typeof v === "object" && !Array.isArray(v)) ? (v as D) : {}; }
function has(v: unknown): boolean { return v != null && v !== "" && !(Array.isArray(v) && v.length === 0); }

function SectionCard({
  title, children, defaultOpen = true, accent, icon
}: {
  title: string; children: React.ReactNode; defaultOpen?: boolean; accent?: string; icon?: React.ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border border-border rounded-xl overflow-hidden bg-card shadow-sm">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between px-5 py-4 text-left hover:bg-muted/40 transition-colors"
      >
        <div className="flex items-center gap-3">
          {accent && <div className="w-1 h-5 rounded-full shrink-0" style={{ background: accent }} />}
          {icon && <span className="text-base">{icon}</span>}
          <span className="font-semibold text-foreground text-sm">{title}</span>
        </div>
        {open ? <ChevronUp className="h-4 w-4 text-muted-foreground shrink-0" /> : <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0" />}
      </button>
      {open && <div className="px-5 pb-5 pt-1 space-y-3">{children}</div>}
    </div>
  );
}

function Label({ text }: { text: string }) {
  return <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-1.5">{text}</p>;
}

function Chip({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-muted/60 rounded-lg p-3">
      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{label}</p>
      <p className="text-foreground text-sm mt-0.5 font-medium">{value}</p>
    </div>
  );
}

function PriereBlock({ data, accent }: { data: D; accent: string }) {
  if (!has(data.priere)) return null;
  const p = obj(data.priere);
  return (
    <SectionCard title="Prière" accent={accent} icon="🙏" defaultOpen={true}>
      {has(p.ouverture) && (
        <div>
          <Label text="Prière d'ouverture" />
          <div className="bg-purple-50 border border-purple-100 rounded-xl p-4 italic text-sm text-foreground leading-relaxed">{str(p.ouverture)}</div>
        </div>
      )}
      {has(p.intercession) && (
        <div>
          <Label text="Point d'intercession" />
          <p className="text-sm text-foreground">{str(p.intercession)}</p>
        </div>
      )}
      {has(p.finale) && (
        <div>
          <Label text="Prière finale du moniteur" />
          <div className="bg-purple-50 border border-purple-100 rounded-xl p-4 italic text-sm text-foreground leading-relaxed">{str(p.finale)}</div>
        </div>
      )}
    </SectionCard>
  );
}

function ElaborationBlock({ data, accent }: { data: D; accent: string }) {
  if (!has(data.elaboration)) return null;
  const elab = obj(data.elaboration);
  const etapes = arr<{ phase: string; duree: string; description: string }>(elab.etapes);
  const script = str(elab.scriptComplet);
  return (
    <SectionCard title="Déroulé complet de la séance" accent={accent} icon="📋" defaultOpen={false}>
      {has(elab.dureeTotal) && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
          <span className="font-semibold text-foreground">Durée totale :</span> {str(elab.dureeTotal)}
        </div>
      )}
      {script && script !== "undefined" && (
        <div className="bg-muted/30 border border-border rounded-xl p-4">
          <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">📝 Script du moniteur (mot à mot)</p>
          <p className="text-sm text-foreground whitespace-pre-wrap leading-relaxed">{script}</p>
        </div>
      )}
      {etapes.length > 0 && (
        <div className="space-y-2 mt-3">
          {etapes.map((e, i) => (
            <div key={i} className="flex gap-3 p-3 rounded-lg border border-border hover:bg-muted/20 transition-colors">
              <div className="shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white mt-0.5" style={{ background: accent }}>{i + 1}</div>
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2 mb-1">
                  <span className="font-semibold text-foreground text-xs">{e.phase}</span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">{e.duree}</span>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">{e.description}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </SectionCard>
  );
}

function ConseilsBlock({ data, accent }: { data: D; accent: string }) {
  const conseils = arr<string>(data.conseilsMoniteur);
  if (conseils.length === 0) return null;
  return (
    <SectionCard title="Conseils pour le moniteur" accent={accent} icon="💡" defaultOpen={true}>
      <div className="space-y-2">
        {conseils.map((c, i) => (
          <div key={i} className="flex gap-2.5 p-3 rounded-lg border border-amber-100 bg-amber-50/60">
            <span className="text-amber-500 shrink-0 mt-0.5">💡</span>
            <p className="text-sm text-foreground leading-relaxed">{c}</p>
          </div>
        ))}
      </div>
    </SectionCard>
  );
}

function Section1({ data }: { data: D }) {
  const blue = "#3b82f6";
  const sdv = obj(data.situationDeVie);
  const et = obj(data.exploitationTexte);
  const lr = obj((data.lectureEtResume ?? data.lectureTexte) as unknown);
  const materiels = arr<string>(data.materielNecessaire);
  const chants = arr<{ titre: string; lien?: string; paroles: string }>(data.chantsDeLouange);
  const motsCles = arr<{ mot: string; definition: string }>(lr.motsCles);
  const sdvQs = arr<string>(sdv.questions);
  const etQs = arr<{ question: string; reponseAttendue: string; verset?: string }>(et.questions);

  return (
    <div className="space-y-3">
      {/* Compétence */}
      {has(data.competence) && (
        <SectionCard title="Compétence à développer" accent={blue} icon="⚡">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
            <p className="text-foreground leading-relaxed text-sm font-medium">{str(data.competence)}</p>
          </div>
        </SectionCard>
      )}

      {/* Matériel */}
      {materiels.length > 0 && (
        <SectionCard title="Matériel nécessaire" accent={blue} icon="🎒" defaultOpen={true}>
          <div className="flex flex-wrap gap-2">
            {materiels.map((m, i) => (
              <span key={i} className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-full bg-blue-50 border border-blue-200 text-blue-700">
                ✓ {m}
              </span>
            ))}
          </div>
        </SectionCard>
      )}

      {/* Prière */}
      <PriereBlock data={data} accent={blue} />

      {/* Chants */}
      {chants.length > 0 && (
        <SectionCard title="Chants de louange" accent={blue} icon="🎵" defaultOpen={true}>
          <div className="space-y-3">
            {chants.map((c, i) => (
              <div key={i} className="border border-blue-100 rounded-xl p-4 bg-blue-50/30">
                <div className="flex items-start gap-2 mb-2">
                  <span className="text-base">🎵</span>
                  <div>
                    <p className="font-semibold text-sm text-foreground">{c.titre}</p>
                    {c.lien && <p className="text-xs text-muted-foreground italic">{c.lien}</p>}
                  </div>
                </div>
                {has(c.paroles) && (
                  <div className="bg-white/70 rounded-lg p-3 border border-blue-100">
                    <p className="text-sm text-foreground whitespace-pre-wrap italic leading-relaxed">{c.paroles}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </SectionCard>
      )}

      {/* Situation de vie */}
      {has(data.situationDeVie) && (
        <SectionCard title="Situation de vie" accent={blue} icon="🌍" defaultOpen={true}>
          <div className="bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-3 text-xs text-amber-800">
            ⚠️ Collecter les hypothèses des enfants SANS les valider à ce stade — la validation se fera en fin de leçon.
          </div>
          <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 mb-3">
            <p className="text-foreground leading-relaxed italic text-sm">{str(sdv.histoire)}</p>
          </div>
          {sdvQs.length > 0 && (
            <div>
              <Label text="Questions (max 1-2)" />
              <div className="space-y-1.5">
                {sdvQs.map((q, i) => (
                  <div key={i} className="flex gap-2 text-sm text-foreground py-1.5 border-b border-border last:border-0">
                    <span className="text-blue-500 font-bold shrink-0">→</span> {q}
                  </div>
                ))}
              </div>
            </div>
          )}
          <div className="grid grid-cols-2 gap-2 mt-3">
            {has(sdv.contexte) && <Chip label="Contexte" value={str(sdv.contexte)} />}
            {has(sdv.cible) && <Chip label="Cible" value={str(sdv.cible)} />}
            {has(sdv.paradoxe) && <Chip label="Paradoxe" value={str(sdv.paradoxe)} />}
            {has(sdv.tache) && <Chip label="Tâche" value={str(sdv.tache)} />}
          </div>
        </SectionCard>
      )}

      {/* Lecture & Résumé */}
      {(has(data.lectureEtResume) || has(data.lectureTexte)) && (
        <SectionCard title="Lecture et résumé du texte" accent={blue} icon="📖" defaultOpen={true}>
          {has(lr.strategie) && (
            <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 mb-3">
              <Label text="Stratégie de lecture" />
              <p className="text-sm text-foreground">{str(lr.strategie)}</p>
            </div>
          )}
          {has(lr.resume) && (
            <div className="border border-blue-200 rounded-xl p-4 mb-3">
              <Label text="Résumé (à lire pour les petits)" />
              <p className="text-sm text-foreground leading-relaxed italic">{str(lr.resume)}</p>
            </div>
          )}
          {motsCles.length > 0 && (
            <div>
              <Label text="Termes clés à expliquer" />
              <div className="space-y-2">
                {motsCles.map((m, i) => (
                  <div key={i} className="flex gap-3 items-start p-2.5 rounded-lg border border-border">
                    <span className="font-bold text-blue-600 text-sm shrink-0 min-w-[80px]">{m.mot}</span>
                    <span className="text-muted-foreground text-sm">{m.definition}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </SectionCard>
      )}

      {/* Exploitation du texte */}
      {(etQs.length > 0 || has(et.noteMoniteur)) && (
        <SectionCard title="Exploitation du texte" accent={blue} icon="❓" defaultOpen={true}>
          {has(et.noteMoniteur) && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-3 text-xs text-amber-800">
              ⚠️ {str(et.noteMoniteur)}
            </div>
          )}
          <div className="space-y-2">
            {etQs.map((q, i) => (
              <div key={i} className="border border-border rounded-lg p-3.5 hover:bg-muted/30 transition-colors">
                <p className="font-semibold text-foreground text-sm mb-1">Q{i + 1} : {q.question}</p>
                <p className="text-xs text-muted-foreground pl-3 border-l-2 border-blue-200 leading-relaxed">→ {q.reponseAttendue}</p>
                {q.verset && <p className="text-xs text-blue-500 mt-1.5 font-medium">📖 {q.verset}</p>}
              </div>
            ))}
          </div>
          {/* Retenons — découvert par les enfants */}
          {(has(et.questionRetenons) || has(data.retenons)) && (
            <div className="mt-3 border border-blue-200 rounded-xl p-4 bg-blue-50">
              <p className="text-xs font-bold text-blue-700 mb-1">⭐ RETENONS — formulé par les enfants</p>
              {has(et.questionRetenons) && (
                <p className="font-semibold text-foreground text-sm mb-2">❓ {str(et.questionRetenons)}</p>
              )}
              {(has(et.reponseRetenons) || has(data.retenons)) && (
                <p className="text-xs text-muted-foreground pl-3 border-l-2 border-blue-300 leading-relaxed">
                  → {str(et.reponseRetenons || data.retenons)}
                </p>
              )}
            </div>
          )}
          {/* Message Central — découvert par les enfants */}
          {(has(et.questionMessageCentral) || has(data.messageCentral)) && (
            <div className="mt-2 border border-primary/20 rounded-xl p-4 bg-primary/5">
              <p className="text-xs font-bold text-primary/70 mb-1">✝️ MESSAGE CENTRAL — dégagé par les enfants</p>
              {has(et.questionMessageCentral) && (
                <p className="font-semibold text-foreground text-sm mb-2">❓ {str(et.questionMessageCentral)}</p>
              )}
              {(has(et.reponseMessageCentral) || has(data.messageCentral)) && (
                <p className="text-xs text-foreground pl-3 border-l-2 border-primary/30 leading-relaxed italic">
                  → {str(et.reponseMessageCentral || data.messageCentral)}
                </p>
              )}
            </div>
          )}
        </SectionCard>
      )}

      {/* Retour à la situation de vie */}
      {has(data.retourSituationDeVie) && (
        <SectionCard title="Retour à la situation de vie" accent={blue} icon="🔄" defaultOpen={true}>
          <div className="bg-blue-50 border border-blue-100 rounded-xl p-4">
            <p className="text-xs font-bold text-blue-700 mb-2">✅ Validation des hypothèses</p>
            <p className="text-sm text-foreground leading-relaxed">{str(data.retourSituationDeVie)}</p>
          </div>
        </SectionCard>
      )}

      {/* Déroulé / Script */}
      <ElaborationBlock data={data} accent={blue} />

      {/* Conseils */}
      <ConseilsBlock data={data} accent={blue} />
    </div>
  );
}

function Section2({ data }: { data: D }) {
  const green = "#16a34a";
  const ev = obj(data.evaluationSommative);
  const ai = obj(data.activiteIntegration);
  const lf = obj(data.liaisonFamiliale);
  const rappel = obj(data.rappelSequence1);
  const evQs = arr<{ question: string; reponseAttendue: string; pointsAttention?: string }>(ev.questionsHistoire);
  const aiQs = arr<{ question: string; reponseAttendue?: string; guidanceReponse?: string }>(ai.questions);
  const aiSp = obj(ai.situationProbleme);
  const qmc = obj(ev.questionMessageCentral);
  const lfDisc = arr<string>(lf.discussionEnFamille);
  const rappelQs = arr<string>(rappel.questionsRappel);

  return (
    <div className="space-y-3">
      {/* Prière */}
      <PriereBlock data={data} accent={green} />

      {/* Rappel Séquence 1 */}
      {has(data.rappelSequence1) && (
        <SectionCard title="Rappel de la Séquence 1" accent={green} icon="🔄" defaultOpen={true}>
          {has(rappel.instructionMCE) && (
            <div className="bg-green-50 border border-green-200 rounded-lg px-3 py-2 mb-2 text-xs text-green-800 font-medium">
              ℹ️ {str(rappel.instructionMCE)}
            </div>
          )}
          {has(rappel.resumeBref) && <p className="text-sm text-foreground leading-relaxed mb-2">{str(rappel.resumeBref)}</p>}
          {rappelQs.length > 0 && (
            <div className="space-y-1.5">
              {rappelQs.map((q, i) => (
                <div key={i} className="flex gap-2 text-sm text-foreground py-1.5 border-b border-border last:border-0">
                  <span className="text-green-500 font-bold shrink-0">→</span> {q}
                </div>
              ))}
            </div>
          )}
          {has(rappel.questionRevision) && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3 mt-2">
              <Label text="Question de révision rapide" />
              <p className="text-sm text-foreground font-medium">{str(rappel.questionRevision)}</p>
            </div>
          )}
          {has(rappel.chantRappel) && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
              <span>🎵</span> Chant : <span className="text-foreground font-medium">{str(rappel.chantRappel)}</span>
            </div>
          )}
        </SectionCard>
      )}

      {/* Évaluation sommative */}
      {has(data.evaluationSommative) && (
        <SectionCard title="Évaluation sommative" accent={green} icon="📝" defaultOpen={true}>
          {(has(ev.noteMoniteur) || has(ev.consigneMoniteur)) && (
            <div className="bg-green-50 border border-green-100 rounded-lg p-3 mb-3 text-sm text-foreground italic">
              💬 {str(ev.noteMoniteur || ev.consigneMoniteur)}
            </div>
          )}
          <div className="space-y-2">
            {evQs.map((q, i) => (
              <div key={i} className="border border-border rounded-lg p-3.5 hover:bg-muted/30 transition-colors">
                <p className="font-semibold text-foreground text-sm mb-1">Q{i + 1} : {q.question}</p>
                <p className="text-xs text-muted-foreground pl-3 border-l-2 border-green-200 leading-relaxed">→ {q.reponseAttendue}</p>
                {q.pointsAttention && <p className="text-xs text-amber-600 mt-1.5 flex gap-1.5"><AlertTriangle className="h-3 w-3 shrink-0 mt-0.5" />{q.pointsAttention}</p>}
              </div>
            ))}
            {has(qmc.question) && (
              <div className="border border-green-200 rounded-lg p-3.5 bg-green-50">
                <p className="text-xs font-bold text-green-700 mb-1">✝ MESSAGE CENTRAL</p>
                <p className="font-semibold text-foreground text-sm mb-1">{str(qmc.question)}</p>
                {has(qmc.reponseAttendue) && <p className="text-xs text-muted-foreground pl-3 border-l-2 border-green-300">→ {str(qmc.reponseAttendue)}</p>}
              </div>
            )}
            {has(ev.questionApplication) && (
              <div className="border border-green-200 rounded-lg p-3.5 bg-green-50/50">
                <p className="text-xs font-bold text-green-700 mb-1">🌱 APPLICATION (formule officielle APC)</p>
                <p className="text-foreground text-sm italic leading-relaxed">{str(ev.questionApplication)}</p>
              </div>
            )}
          </div>
        </SectionCard>
      )}

      {/* Activité d'intégration */}
      {has(data.activiteIntegration) && (
        <SectionCard title="Activité d'intégration (à faire à la maison)" accent={green} icon="🏠" defaultOpen={true}>
          <div className="bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-3 text-xs text-amber-800">
            ⚠️ Travail INDIVIDUEL à faire à la MAISON par l'enfant SEUL. Max 6 lignes + 2-3 questions. Dernière question = production pratique.
          </div>
          {(has(ai.noteMoniteur) || has(ai.consigneMoniteur)) && (
            <div className="bg-green-50 border border-green-100 rounded-lg p-3 mb-3 text-sm text-foreground italic">
              💬 {str(ai.noteMoniteur || ai.consigneMoniteur)}
            </div>
          )}
          {has(ai.situationProbleme) && (
            <div className="bg-green-50 border border-green-100 rounded-xl p-4 mb-3">
              <p className="text-xs font-bold text-green-700 mb-2">📖 Situation-problème (max 6 lignes)</p>
              <p className="text-foreground italic leading-relaxed text-sm">{str(aiSp.histoire)}</p>
              {has(aiSp.tache) && <p className="text-xs text-muted-foreground mt-2 font-medium">📌 Tâche : {str(aiSp.tache)}</p>}
              <div className="grid grid-cols-2 gap-2 mt-3">
                {has(aiSp.contexte) && <Chip label="Contexte" value={str(aiSp.contexte)} />}
                {has(aiSp.cible) && <Chip label="Cible" value={str(aiSp.cible)} />}
                {has(aiSp.paradoxe) && <Chip label="Paradoxe" value={str(aiSp.paradoxe)} />}
              </div>
            </div>
          )}
          <div className="space-y-2">
            {aiQs.map((q, i) => (
              <div key={i} className={`border rounded-lg p-3.5 ${i === aiQs.length - 1 ? "border-green-300 bg-green-50" : "border-border"}`}>
                <div className="flex gap-2 items-center mb-1">
                  {i === aiQs.length - 1 && <span className="text-xs font-bold text-green-700 bg-green-100 px-2 py-0.5 rounded-full">🎨 PRODUCTION PRATIQUE</span>}
                </div>
                <p className="font-semibold text-foreground text-sm mb-1">Q{i + 1} : {q.question}</p>
                <p className="text-xs text-muted-foreground pl-3 border-l-2 border-green-200 leading-relaxed">
                  → {str(q.reponseAttendue || q.guidanceReponse)}
                </p>
              </div>
            ))}
          </div>
          {has(ai.noteActivitePetits) && (
            <div className="mt-3 bg-blue-50 border border-blue-100 rounded-lg p-3">
              <p className="text-xs font-bold text-blue-700 mb-1">👶 Pour les petits (Maternelle–CE1)</p>
              <p className="text-xs text-blue-800 mb-2">{str(ai.noteActivitePetits)}</p>
              {has(ai.activitePetits) && <p className="text-sm text-foreground">{str(ai.activitePetits)}</p>}
            </div>
          )}
        </SectionCard>
      )}

      {/* Liaison familiale */}
      {has(data.liaisonFamiliale) && (
        <SectionCard title="Liaison familiale" accent={green} icon="👨‍👩‍👧" defaultOpen={true}>
          {has(lf.noteMoniteur) && (
            <div className="bg-green-50 border border-green-100 rounded-lg px-3 py-2 mb-3 text-xs text-green-800">
              ℹ️ {str(lf.noteMoniteur)}
            </div>
          )}
          <div className="space-y-3">
            {has(lf.resumeRecit) && (
              <div>
                <Label text="Résumé du récit biblique (pour les parents)" />
                <p className="text-foreground text-sm leading-relaxed">{str(lf.resumeRecit)}</p>
              </div>
            )}
            {has(lf.messageCentralEtCompetence) && (
              <div className="bg-green-50 border border-green-100 rounded-lg p-3">
                <Label text="Message central et compétence à développer" />
                <p className="text-foreground text-sm italic">{str(lf.messageCentralEtCompetence)}</p>
              </div>
            )}
            {lfDisc.length > 0 && (
              <div>
                <Label text="Discussion en famille" />
                <div className="space-y-1.5">
                  {lfDisc.map((d, i) => (
                    <div key={i} className="flex gap-2 text-sm text-foreground p-2 rounded-lg border border-green-100 bg-green-50/40">
                      <span className="text-green-500 shrink-0 font-bold">{i + 1}.</span> {d}
                    </div>
                  ))}
                </div>
              </div>
            )}
            {has(lf.versetAMediter) && (
              <div className="bg-primary/5 border-l-4 rounded-r-xl p-3" style={{ borderColor: green }}>
                <Label text="Verset à méditer en famille" />
                <p className="text-foreground text-sm italic">{str(lf.versetAMediter)}</p>
              </div>
            )}
            {has(lf.messageParents) && (
              <div className="bg-amber-50 border border-amber-100 rounded-xl p-3">
                <Label text="Message aux parents" />
                <p className="text-foreground text-sm italic">{str(lf.messageParents)}</p>
              </div>
            )}
          </div>
        </SectionCard>
      )}

      {/* Déroulé / Script */}
      <ElaborationBlock data={data} accent={green} />

      {/* Conseils */}
      <ConseilsBlock data={data} accent={green} />
    </div>
  );
}

function Section3({ data }: { data: D }) {
  const amber = "#d97706";
  const pm = obj(data.partageMoniteur);
  const ai = obj(data.appreciationIntegration);
  const vi = obj(data.verificationIntegrations);
  const rl = obj(data.rappelLecon);
  const lfv = obj((data.verificationLiaisonFamiliale ?? data.liaisonFamilialeVerification) as unknown);
  const viQs = arr<{ question: string; reponseAttendue: string; critere?: string }>(vi.corrigeIntegration);
  const aiCorrige = arr<{ question: string; reponseAttendue: string }>(ai.corrigeHarmonise);
  const aiFormules = arr<string>(ai.formulesDAppreciation);
  const aiTypes = arr<string>(ai.typesDesDifficultesARelever);
  const lfvQs = arr<string>(lfv.questionsVerification);
  const rappelEls = arr<string>(rl.elementsARappeler);

  return (
    <div className="space-y-3">
      {/* Prière */}
      <PriereBlock data={data} accent={amber} />

      {/* Partage du moniteur */}
      {has(data.partageMoniteur) && (
        <SectionCard title="Partage du moniteur (EN PREMIER !)" accent={amber} icon="🗣️" defaultOpen={true}>
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-3">
            <p className="text-xs font-bold text-amber-700 mb-2">⚠️ {str(pm.noteImportante || "LE MONITEUR PARTAGE EN PREMIER — avant d'inviter les enfants")}</p>
          </div>
          {has(pm.exempleTeemoignage) && (
            <div>
              <Label text="Exemple de témoignage à partager" />
              <div className="bg-amber-50/60 border border-amber-100 rounded-xl p-4 italic text-sm text-foreground leading-relaxed">
                {str(pm.exempleTeemoignage)}
              </div>
            </div>
          )}
          {has(pm.description) && !has(pm.exempleTeemoignage) && (
            <p className="text-foreground text-sm leading-relaxed">{str(pm.description)}</p>
          )}
          {has(pm.difficultesHonnetes) && (
            <div className="mt-3">
              <Label text="Difficultés honnêtes à partager" />
              <div className="flex gap-2 text-sm text-foreground p-3 rounded-lg bg-white border border-amber-100">
                <span className="text-amber-400 shrink-0">~</span> {str(pm.difficultesHonnetes)}
              </div>
            </div>
          )}
          {has(pm.transitionVersEnfants) && (
            <div className="mt-3 bg-amber-100 rounded-lg p-3">
              <p className="text-sm text-amber-800 font-medium italic">{str(pm.transitionVersEnfants)}</p>
            </div>
          )}
          {has(pm.consigne) && (
            <div className="mt-2 bg-amber-100 rounded-lg p-3">
              <p className="text-sm text-amber-800 font-medium italic">{str(pm.consigne)}</p>
            </div>
          )}
        </SectionCard>
      )}

      {/* Rappel de la leçon */}
      {(has(data.rappelLecon) || has(data.recueilTemoignages)) && (
        <SectionCard title="Rappel de la leçon" accent={amber} icon="🔄" defaultOpen={true}>
          {rappelEls.length > 0 && (
            <div className="space-y-1.5 mb-3">
              {rappelEls.map((e, i) => (
                <div key={i} className="flex gap-2 text-sm text-foreground p-2 rounded-lg bg-amber-50/50 border border-amber-100">
                  <span className="text-amber-600 shrink-0 font-bold">→</span> {e}
                </div>
              ))}
            </div>
          )}
          {has(rl.rappelActiviteIntegration) && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
              <Label text="Rappel de l'activité d'intégration (Séquence 2)" />
              <p className="text-sm text-foreground">{str(rl.rappelActiviteIntegration)}</p>
            </div>
          )}
        </SectionCard>
      )}

      {/* Appréciation de l'intégration — SANS corriger */}
      {(has(data.appreciationIntegration) || viQs.length > 0) && (
        <SectionCard title="Appréciation des travaux d'intégration" accent={amber} icon="👂" defaultOpen={true}>
          {has(ai.regleFondamentale) && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-3">
              <p className="text-xs font-bold text-red-700 mb-1">🚫 RÈGLE FONDAMENTALE</p>
              <p className="text-sm text-red-800">{str(ai.regleFondamentale)}</p>
            </div>
          )}
          {aiFormules.length > 0 && (
            <div className="mb-3">
              <Label text="Formules d'appréciation à utiliser" />
              <div className="space-y-1.5">
                {aiFormules.map((f, i) => (
                  <div key={i} className="flex gap-2 text-sm text-foreground p-2 rounded-lg bg-amber-50/50 border border-amber-100 italic">
                    <span className="text-amber-600 shrink-0">💬</span> {f}
                  </div>
                ))}
              </div>
            </div>
          )}
          {(aiCorrige.length > 0 || viQs.length > 0) && (
            <div className="mb-3">
              <Label text="Corrigé harmonisé (pour le MCE — à NE PAS donner directement)" />
              <div className="space-y-2">
                {(aiCorrige.length > 0 ? aiCorrige : viQs).map((q, i) => (
                  <div key={i} className="border border-border rounded-lg p-3.5">
                    <p className="font-semibold text-foreground text-sm mb-1">Q{i + 1} : {q.question}</p>
                    <p className="text-xs text-muted-foreground pl-3 border-l-2 border-amber-200 leading-relaxed">→ {q.reponseAttendue}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
          {aiTypes.length > 0 && (
            <div>
              <Label text="Types de difficultés à relever (base de la Séquence 4)" />
              <div className="space-y-1.5">
                {aiTypes.map((t, i) => (
                  <div key={i} className="flex gap-2.5 p-2.5 rounded-lg bg-red-50 border border-red-100">
                    <AlertTriangle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
                    <p className="text-xs text-foreground">{t}</p>
                  </div>
                ))}
              </div>
              {has(ai.noteDifficultesPreparation4) && (
                <div className="mt-2 bg-amber-100 border border-amber-200 rounded-lg p-3">
                  <p className="text-xs font-bold text-amber-800">📝 {str(ai.noteDifficultesPreparation4)}</p>
                </div>
              )}
            </div>
          )}
        </SectionCard>
      )}

      {/* Vérification de la liaison familiale */}
      {(has(data.verificationLiaisonFamiliale) || has(data.liaisonFamilialeVerification)) && (
        <SectionCard title="Vérification de la liaison familiale" accent={amber} icon="👨‍👩‍👧" defaultOpen={true}>
          {has(lfv.noteVigilance) && (
            <div className="bg-amber-50 border border-amber-100 rounded-lg px-3 py-2 mb-2 text-xs text-amber-800">
              ℹ️ {str(lfv.noteVigilance)}
            </div>
          )}
          {lfvQs.length > 0 && (
            <div className="space-y-2">
              {lfvQs.map((q, i) => (
                <div key={i} className="flex gap-2 text-sm text-foreground py-1.5 border-b border-border last:border-0">
                  <span className="text-amber-500 font-bold shrink-0">?</span> {q}
                </div>
              ))}
            </div>
          )}
          {has(lfv.activitePratique) && (
            <div className="bg-amber-50 border border-amber-100 rounded-lg p-3 mt-2">
              <Label text="Activité pratique" />
              <p className="text-sm text-foreground">{str(lfv.activitePratique)}</p>
            </div>
          )}
          {has(lfv.messageEncouragement) && (
            <div className="bg-blue-50 border border-blue-100 rounded-lg p-3 mt-2">
              <p className="text-sm text-foreground italic">{str(lfv.messageEncouragement)}</p>
            </div>
          )}
        </SectionCard>
      )}

      {/* Déroulé / Script */}
      <ElaborationBlock data={data} accent={amber} />

      {/* Conseils */}
      <ConseilsBlock data={data} accent={amber} />
    </div>
  );
}

function Section4({ data }: { data: D }) {
  const red = "#dc2626";
  const rl4 = obj((data.recapitulatifCycle ?? data.recapitulatifLecon) as unknown);
  const rappel = obj(data.rappelLecon);
  const diffR = obj(data.difficultesRelevees);
  const typesDiffs = arr<{ type: string; description: string; groupeConcerne: string }>(diffR.typesFrequents);
  const groupes = arr<{ nomGroupe: string; difficulte: string; solution: string; activite: string; materiel: string[] }>(data.groupesDeRemediation);
  const rgu = obj(data.remediationGroupeUnique);
  const rguOrdre = arr<string>(rgu.ordreResolution);
  const pointsCles = arr<string>(rl4.pointsCles);
  const diffs = arr<{ difficulte: string; cause: string; solutionRemediation: string; exempleActivite?: string }>(data.difficultesCourantes);
  const meths = arr<{ methode: string; description: string; pourQui?: string; materielNecessaire: string[] }>(data.methodesRemediation);

  return (
    <div className="space-y-3">
      {/* Prière */}
      <PriereBlock data={data} accent={red} />

      {/* Rappel de la leçon */}
      {has(data.rappelLecon) && (
        <SectionCard title="Rappel de la leçon" accent={red} icon="📌" defaultOpen={true}>
          <div className="grid grid-cols-1 gap-2">
            {has(rappel.titre) && <Chip label="Titre" value={str(rappel.titre)} />}
            {has(rappel.reference) && <Chip label="Référence" value={str(rappel.reference)} />}
            {has(rappel.competence) && <Chip label="Compétence" value={str(rappel.competence)} />}
            {has(rappel.messageCentral) && (
              <div className="bg-primary/5 border-l-4 border-primary/30 rounded-r-xl p-3">
                <p className="text-xs font-bold text-primary/70 mb-1">✝️ Message central</p>
                <p className="text-sm text-foreground italic">{str(rappel.messageCentral)}</p>
              </div>
            )}
          </div>
        </SectionCard>
      )}

      {/* Difficultés relevées en Séquence 3 */}
      {(has(data.difficultesRelevees) || diffs.length > 0 || typesDiffs.length > 0) && (
        <SectionCard title="Difficultés relevées (Séquence 3)" accent={red} icon="🔍" defaultOpen={true}>
          {has(diffR.noteMoniteur) && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-3 text-xs text-amber-800">
              ℹ️ {str(diffR.noteMoniteur)}
            </div>
          )}
          {typesDiffs.length > 0 && (
            <div className="space-y-3">
              {typesDiffs.map((d, i) => (
                <div key={i} className="border border-red-200 rounded-xl p-4 bg-red-50/30 space-y-2">
                  <p className="font-bold text-foreground text-sm">{d.type}</p>
                  <p className="text-xs text-muted-foreground">{d.description}</p>
                  <span className="inline-flex text-xs px-2 py-1 rounded-full bg-red-100 text-red-700 font-medium">{d.groupeConcerne}</span>
                </div>
              ))}
            </div>
          )}
          {diffs.length > 0 && typesDiffs.length === 0 && (
            <div className="space-y-3">
              {diffs.map((d, i) => (
                <div key={i} className="border border-border rounded-xl p-4 space-y-2">
                  <p className="font-bold text-foreground text-sm">Difficulté {i + 1} : {d.difficulte}</p>
                  <p className="text-xs text-muted-foreground flex gap-1.5 items-start"><Info className="h-3.5 w-3.5 shrink-0 mt-0.5" />Cause : {d.cause}</p>
                </div>
              ))}
            </div>
          )}
        </SectionCard>
      )}

      {/* Groupes de remédiation */}
      {(groupes.length > 0 || meths.length > 0) && (
        <SectionCard title="Groupes de remédiation" accent={red} icon="👥" defaultOpen={true}>
          <div className="bg-amber-50 border border-amber-100 rounded-lg px-3 py-2 mb-3 text-xs text-amber-800">
            💡 Si l'effectif le permet, diviser en petits groupes selon le type de difficulté. Sinon, traiter en groupe unique.
          </div>
          <div className="space-y-4">
            {(groupes.length > 0 ? groupes : meths).map((g, i) => (
              <div key={i} className="border border-border rounded-xl p-4 space-y-3">
                <p className="font-bold text-foreground text-sm">
                  {(g as typeof groupes[0]).nomGroupe || (g as typeof meths[0]).methode}
                </p>
                {(g as typeof groupes[0]).difficulte && (
                  <div className="flex gap-2 items-start">
                    <AlertTriangle className="h-3.5 w-3.5 text-red-500 shrink-0 mt-0.5" />
                    <p className="text-xs text-muted-foreground">{(g as typeof groupes[0]).difficulte}</p>
                  </div>
                )}
                {(g as typeof groupes[0]).solution && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                    <p className="text-xs font-bold text-green-700 mb-1">✅ SOLUTION</p>
                    <p className="text-sm text-green-800">{(g as typeof groupes[0]).solution}</p>
                  </div>
                )}
                {(g as typeof groupes[0]).activite && (
                  <div className="bg-blue-50 border border-blue-100 rounded-lg p-3">
                    <p className="text-xs font-bold text-blue-700 mb-1">🎯 Activité de remédiation</p>
                    <p className="text-sm text-blue-800">{(g as typeof groupes[0]).activite}</p>
                  </div>
                )}
                {arr<string>((g as typeof groupes[0]).materiel ?? (g as typeof meths[0]).materielNecessaire).length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {arr<string>((g as typeof groupes[0]).materiel ?? (g as typeof meths[0]).materielNecessaire).map((m, j) => (
                      <span key={j} className="text-xs px-2 py-1 rounded bg-muted text-muted-foreground">• {m}</span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </SectionCard>
      )}

      {/* Remédiation groupe unique */}
      {has(data.remediationGroupeUnique) && rguOrdre.length > 0 && (
        <SectionCard title="Remédiation en groupe unique (si pas de petits groupes)" accent={red} icon="🔁" defaultOpen={false}>
          {has(rgu.note) && (
            <div className="bg-muted/40 rounded-lg px-3 py-2 mb-2 text-xs text-muted-foreground italic">{str(rgu.note)}</div>
          )}
          <div className="space-y-1.5">
            {rguOrdre.map((e, i) => (
              <div key={i} className="flex gap-3 p-2.5 rounded-lg border border-border">
                <div className="shrink-0 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold text-white" style={{ background: red }}>{i + 1}</div>
                <p className="text-sm text-foreground">{e}</p>
              </div>
            ))}
          </div>
        </SectionCard>
      )}

      {/* Récapitulatif du cycle */}
      {(has(data.recapitulatifCycle) || has(data.recapitulatifLecon)) && (
        <SectionCard title="Récapitulatif du cycle (4 séquences)" accent={red} icon="📋" defaultOpen={true}>
          {(has(rl4.messageFinal) || has(rl4.messageCentral)) && (
            <div className="bg-primary/5 border-l-4 border-primary/30 rounded-r-xl p-4 mb-3">
              <p className="italic text-foreground text-sm">{str(rl4.messageFinal || rl4.messageCentral)}</p>
            </div>
          )}
          {has(rl4.competenceVisee) && (
            <div className="mb-3">
              <Label text="Compétence développée" />
              <p className="text-foreground text-sm font-medium">{str(rl4.competenceVisee)}</p>
            </div>
          )}
          {pointsCles.length > 0 && (
            <div>
              <Label text="Points clés à retenir" />
              <div className="space-y-1.5">
                {pointsCles.map((p, i) => (
                  <div key={i} className="flex gap-2.5 items-start p-2.5 rounded-lg bg-muted/40">
                    <span className="w-5 h-5 rounded-full bg-red-100 text-red-600 flex items-center justify-center text-xs font-bold shrink-0">{i + 1}</span>
                    <p className="text-sm text-foreground">{p}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
          {has(rl4.versetsMemorise) && (
            <div className="bg-blue-50 border border-blue-100 rounded-lg p-3 mt-3">
              <Label text="Versets mémorisés" />
              <p className="text-sm text-foreground italic">{str(rl4.versetsMemorise)}</p>
            </div>
          )}
        </SectionCard>
      )}

      {/* Déroulé / Script */}
      <ElaborationBlock data={data} accent={red} />

      {/* Encouragements */}
      {has(data.encouragements) && (
        <div className="rounded-xl p-6 text-center" style={{ background: "linear-gradient(135deg, hsl(220 55% 30% / 0.06) 0%, hsl(43 88% 52% / 0.08) 100%)", border: "1px solid hsl(220 55% 30% / 0.15)" }}>
          <p className="text-2xl mb-3">🙌</p>
          <p className="text-foreground italic leading-relaxed text-sm">{str(data.encouragements)}</p>
        </div>
      )}

      {/* Conseils */}
      <ConseilsBlock data={data} accent={red} />
    </div>
  );
}

function renderContent(sequence: number, data: D) {
  if (sequence === 1) return <Section1 data={data} />;
  if (sequence === 2) return <Section2 data={data} />;
  if (sequence === 3) return <Section3 data={data} />;
  if (sequence === 4) return <Section4 data={data} />;
  return null;
}

export default function GeneratorPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [generating, setGenerating] = useState(false);
  const [parsedData, setParsedData] = useState<D | null>(null);
  const [generationError, setGenerationError] = useState("");
  const [lastForm, setLastForm] = useState<FormValues | null>(null);
  const createLesson = useCreateLesson();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { titre: "", reference: "", trancheAge: "moyens", sequence: "1", contexteLecon: "" },
  });

  const watchSeq = form.watch("sequence");
  const watchAge = form.watch("trancheAge");
  const currentSeq = SEQUENCES.find(s => s.value === watchSeq)!;

  async function onSubmit(values: FormValues) {
    setGenerating(true);
    setParsedData(null);
    setGenerationError("");
    setLastForm(values);
    try {
      const BASE = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");
      const response = await fetch(`${BASE}/api/lessons/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          titre: values.titre,
          reference: values.reference,
          trancheAge: values.trancheAge,
          sequence: parseInt(values.sequence),
          contexteLecon: values.contexteLecon || undefined,
        }),
      });
      if (!response.body) throw new Error("Pas de réponse");
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let accumulated = "";
      function cleanJson(s: string): string {
        return s.replace(/^```(?:json)?\s*/i, "").replace(/\s*```\s*$/, "").trim();
      }
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const evt = JSON.parse(line.slice(6));
              if (evt.content) {
                accumulated += evt.content;
                try { setParsedData(JSON.parse(cleanJson(accumulated))); } catch {}
              }
              if (evt.done) {
                setGenerating(false);
                try { setParsedData(JSON.parse(cleanJson(accumulated))); }
                catch { setGenerationError("Réponse invalide. Réessayez."); }
              }
              if (evt.error) { setGenerationError(evt.error); setGenerating(false); }
            } catch {}
          }
        }
      }
    } catch {
      setGenerationError("Erreur de connexion. Veuillez réessayer.");
      setGenerating(false);
    }
  }

  async function handleSave() {
    if (!parsedData || !lastForm) return;
    try {
      const lesson = await createLesson.mutateAsync({
        data: {
          titre: lastForm.titre,
          reference: lastForm.reference,
          trancheAge: lastForm.trancheAge,
          sequence: parseInt(lastForm.sequence),
          contenu: JSON.stringify(parsedData),
        },
      });
      await queryClient.invalidateQueries({ queryKey: getListLessonsQueryKey() });
      await queryClient.invalidateQueries({ queryKey: getGetLessonsStatsQueryKey() });
      toast({ title: "Leçon sauvegardée !", description: "Retrouvez-la dans Mes Leçons." });
      setLocation(`/lecon/${lesson.id}`);
    } catch {
      toast({ title: "Erreur", description: "Impossible de sauvegarder.", variant: "destructive" });
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div
        className="relative rounded-2xl overflow-hidden p-7 text-white shadow-lg"
        style={{ background: "linear-gradient(135deg, hsl(220 55% 28%) 0%, hsl(220 55% 20%) 100%)" }}
      >
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: "radial-gradient(circle at 80% 20%, white 1px, transparent 1px), radial-gradient(circle at 20% 80%, white 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }} />
        <div className="relative flex flex-col md:flex-row items-start md:items-center gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="h-5 w-5" style={{ color: "hsl(43 88% 65%)" }} />
              <p className="text-xs font-bold uppercase tracking-widest" style={{ color: "hsl(43 88% 65%)" }}>
                IA — Approche par Compétence EEC
              </p>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold leading-tight mb-1">Préparer une leçon</h1>
            <p className="text-white/65 text-sm">
              Renseignez les informations ci-dessous. L'IA génère votre fiche de préparation complète, riche et prête à l'emploi.
            </p>
          </div>
          <img src="/logo.jpg" alt="Logo" className="w-16 h-16 rounded-xl object-cover border-2 border-white/20 shadow-lg hidden md:block" />
        </div>
      </div>

      {/* Form card */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">

        {/* Séquence picker */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0" style={{ background: "hsl(220 55% 30% / 0.1)" }}>
              <Layers className="h-4 w-4" style={{ color: "hsl(220 55% 30%)" }} />
            </div>
            <p className="font-semibold text-foreground text-sm">Choisir la séquence</p>
          </div>
          <Form {...form}>
            <FormField control={form.control} name="sequence" render={({ field }) => (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {SEQUENCES.map(seq => (
                  <button
                    key={seq.value}
                    type="button"
                    onClick={() => field.onChange(seq.value)}
                    className="rounded-xl p-3 border-2 text-left transition-all cursor-pointer"
                    style={
                      field.value === seq.value
                        ? { background: seq.bg, borderColor: seq.color, boxShadow: `0 0 0 1px ${seq.color}` }
                        : { background: "transparent", borderColor: "hsl(var(--border))" }
                    }
                  >
                    <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white mb-2" style={{ background: seq.color }}>{seq.value}</div>
                    <p className="font-semibold text-xs text-foreground leading-tight">{seq.label}</p>
                    <p className="text-xs text-muted-foreground mt-0.5 leading-tight">{seq.sub}</p>
                  </button>
                ))}
              </div>
            )} />
          </Form>
        </div>

        {/* Age group picker */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0" style={{ background: "hsl(220 55% 30% / 0.1)" }}>
              <Users className="h-4 w-4" style={{ color: "hsl(220 55% 30%)" }} />
            </div>
            <p className="font-semibold text-foreground text-sm">Tranche d'âge</p>
          </div>
          <Form {...form}>
            <FormField control={form.control} name="trancheAge" render={({ field }) => (
              <div className="grid grid-cols-3 gap-3">
                {AGE_GROUPS.map(ag => (
                  <button
                    key={ag.value}
                    type="button"
                    onClick={() => field.onChange(ag.value)}
                    className="rounded-xl p-4 border-2 text-center transition-all cursor-pointer"
                    style={
                      field.value === ag.value
                        ? { background: "hsl(220 55% 30% / 0.08)", borderColor: "hsl(220 55% 30%)", boxShadow: "0 0 0 1px hsl(220 55% 30%)" }
                        : { background: "transparent", borderColor: "hsl(var(--border))" }
                    }
                  >
                    <p className="text-2xl mb-1">{ag.icon}</p>
                    <p className="font-semibold text-sm text-foreground">{ag.label}</p>
                    <p className="text-xs text-muted-foreground">{ag.sub}</p>
                  </button>
                ))}
              </div>
            )} />
          </Form>
        </div>

        {/* Lesson info */}
        <div className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0" style={{ background: "hsl(220 55% 30% / 0.1)" }}>
              <BookOpen className="h-4 w-4" style={{ color: "hsl(220 55% 30%)" }} />
            </div>
            <p className="font-semibold text-foreground text-sm">Informations de la leçon</p>
          </div>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="titre" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium">Titre de la leçon</FormLabel>
                    <FormControl>
                      <Input placeholder="Ex: La foi d'Abraham" className="h-11" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="reference" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium">Référence biblique</FormLabel>
                    <FormControl>
                      <Input placeholder="Ex: Genèse 22:1-18" className="h-11" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <FormField control={form.control} name="contexteLecon" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium">
                    Contexte supplémentaire <span className="text-muted-foreground font-normal">(optionnel)</span>
                  </FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Notes particulières, contexte local, thème du mois, difficulté spécifique à adresser..."
                      className="resize-none"
                      rows={2}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <div className="flex items-center gap-4 pt-2">
                <button
                  type="submit"
                  disabled={generating}
                  className="flex items-center gap-2.5 px-6 py-3 rounded-xl font-semibold text-sm text-white transition-all disabled:opacity-60 disabled:cursor-not-allowed shadow-md hover:shadow-lg active:scale-95"
                  style={{ background: generating ? "hsl(220 55% 38%)" : "hsl(220 55% 28%)" }}
                >
                  {generating
                    ? <><RefreshCw className="h-4 w-4 animate-spin" />Génération en cours…</>
                    : <><Sparkles className="h-4 w-4" />Générer avec l'IA</>
                  }
                </button>
                {parsedData != null && !generating && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                    Préparation prête — pensez à sauvegarder
                  </div>
                )}
              </div>
            </form>
          </Form>
        </div>
      </div>

      {/* Result */}
      {(generating || parsedData) && (
        <div className="space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-3 pb-1">
            <div className="flex items-center gap-3 flex-wrap">
              <h2 className="text-xl font-bold text-foreground">Préparation générée</h2>
              {lastForm && (
                <>
                  <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full border"
                    style={{ background: currentSeq.bg, borderColor: currentSeq.border, color: currentSeq.color }}>
                    {currentSeq.label}
                  </span>
                  <span className="text-xs text-muted-foreground capitalize">{watchAge}</span>
                </>
              )}
            </div>
            {parsedData != null && !generating && (
              <button
                onClick={handleSave}
                disabled={createLesson.isPending}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm text-white transition-all disabled:opacity-60 shadow-sm hover:shadow-md active:scale-95"
                style={{ background: "hsl(220 55% 28%)" }}
              >
                <Save className="h-4 w-4" />
                {createLesson.isPending ? "Sauvegarde…" : "Sauvegarder"}
              </button>
            )}
          </div>

          {generationError !== "" && (
            <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-4 text-destructive text-sm flex gap-2">
              <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
              {generationError}
            </div>
          )}

          {generating && parsedData == null && (
            <div className="bg-card border border-border rounded-xl p-10 flex flex-col items-center gap-4 text-muted-foreground">
              <RefreshCw className="h-9 w-9 animate-spin" style={{ color: "hsl(220 55% 30%)" }} />
              <div className="text-center">
                <p className="font-semibold text-foreground text-base">L'IA prépare votre fiche complète…</p>
                <p className="text-xs mt-1.5">Cela peut prendre 20 à 40 secondes — la leçon sera très détaillée !</p>
              </div>
            </div>
          )}

          {parsedData != null && lastForm != null && renderContent(parseInt(lastForm.sequence), parsedData)}
        </div>
      )}
    </div>
  );
}
