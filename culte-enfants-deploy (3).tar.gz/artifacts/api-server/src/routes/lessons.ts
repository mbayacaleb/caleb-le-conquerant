import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { lessonsTable } from "@workspace/db";
import { desc, eq, count } from "drizzle-orm";
import {
  ListLessonsResponseItem,
  CreateLessonBody,
  GetLessonParams,
  DeleteLessonParams,
  GenerateLessonBody,
} from "@workspace/api-zod";
import { openai } from "@workspace/integrations-openai-ai-server";

const router: IRouter = Router();

router.get("/lessons", async (req, res) => {
  const lessons = await db
    .select()
    .from(lessonsTable)
    .orderBy(desc(lessonsTable.createdAt));
  const parsed = lessons.map((l) =>
    ListLessonsResponseItem.parse({
      id: l.id,
      titre: l.titre,
      reference: l.reference,
      trancheAge: l.trancheAge,
      sequence: l.sequence,
      contenu: l.contenu,
      createdAt: l.createdAt.toISOString(),
    })
  );
  res.json(parsed);
});

router.get("/lessons/stats", async (req, res) => {
  const all = await db.select().from(lessonsTable).orderBy(desc(lessonsTable.createdAt));

  const parSequence = { sequence1: 0, sequence2: 0, sequence3: 0, sequence4: 0 };
  const parTranche = { petits: 0, moyens: 0, grands: 0 };

  for (const l of all) {
    const key = `sequence${l.sequence}` as keyof typeof parSequence;
    if (key in parSequence) parSequence[key]++;
    const ta = l.trancheAge as keyof typeof parTranche;
    if (ta in parTranche) parTranche[ta]++;
  }

  const recentes = all.slice(0, 5).map((l) => ({
    id: l.id,
    titre: l.titre,
    reference: l.reference,
    trancheAge: l.trancheAge,
    sequence: l.sequence,
    contenu: l.contenu,
    createdAt: l.createdAt.toISOString(),
  }));

  res.json({
    total: all.length,
    parSequence,
    parTranche,
    recentes,
  });
});

router.post("/lessons/generate", async (req, res) => {
  const body = GenerateLessonBody.parse(req.body);
  const { titre, reference, trancheAge, sequence, contexteLecon } = body;

  const trancheLabel =
    trancheAge === "petits"
      ? "petits (Maternelle à CE1, 4-8 ans)"
      : trancheAge === "moyens"
        ? "moyens (CE2 à CM1, 9-11 ans)"
        : "grands (CM2 et plus, 12 ans et plus)";

  const systemPrompt = `Tu es un expert officiel en pédagogie chrétienne APC (Approche par Compétence) de l'Église Évangélique du Cameroun (EEC), formé selon le Manuel de Référence pour la Préparation et la Présentation de Leçon du Département du Culte d'Enfants, Ligues et Chorales de l'EEC.

Tu maîtrises parfaitement les règles officielles du Manuel de Référence APC de l'EEC. Voici les règles ABSOLUES que tu dois respecter dans chaque fiche :

RÈGLES APC OFFICIELLES EEC :
1. COMPÉTENCE : 1-2 phrases MAX avec verbes d'action (identifier, appliquer, démontrer, partager...). Elle dit ce que l'enfant sera capable de FAIRE.
2. SITUATION DE VIE : contexte + cible + paradoxe + tâche + 1-2 questions MAXIMUM. L'enfant propose des hypothèses NON VALIDÉES par le MCE (validation seulement en fin de leçon).
3. RÉSUMÉ : obligatoire si > 3 versets pour les petits (Maternelle-CE1) ou > 10 versets pour les grands (CM2+). Le résumé représente 1/4 du texte, répond à : Qui ? Fait quoi ? Où ? Quand ? Comment ? Avec quel effet ?
4. RETENONS : Ce que l'enfant tire lui-même du texte. Le MCE NE DONNE PAS le retenons — il pose une question finale de synthèse et les enfants le construisent eux-mêmes à partir de leurs réponses à l'exploitation.
5. MESSAGE CENTRAL : Formulé "Pour l'édification de ma foi chrétienne, ce texte m'apprend que...". Le MCE NE LE DONNE PAS aux enfants — il les amène à le dégager par ses questions.
6. EXPLOITATION DU TEXTE : Questions orientées vers la compétence et le titre, PAS une étude biblique. Les réponses progressives permettent de ressortir le "retenons".
7. ÉLABORATION : Script LITTÉRAL mot à mot — ce que le MCE dit exactement du début à la fin, comme s'il présentait devant les enfants.
8. INTÉGRATION (Séquence 2) : Activité à faire à la MAISON par l'enfant SEUL. Situation-problème MAX 6 lignes (contexte+cible+paradoxe+tâche). 2-3 questions MAXIMUM. La DERNIÈRE question débouche TOUJOURS sur une production pratique (dessin, affiche, chant, slogan) adaptée à la tranche d'âge.
9. SÉQUENCE 3 : Le MCE APPRÉCIE le travail des enfants (écoute, encourage) SANS corriger — la correction appartient à la Séquence 4. Il note les difficultés pour préparer la Séquence 4.
10. SÉQUENCE 4 : Remédiation basée UNIQUEMENT sur les difficultés relevées en Séquence 3. Peut se faire en petits groupes par type de difficulté.

STYLE : Langage adapté aux ${trancheLabel}. Exemples du quotidien camerounais/africain (marché, école, famille, quartier). Ton chaleureux et encourageant pour le MCE. Fidèle aux Écritures.

Réponds UNIQUEMENT en JSON valide brut. JAMAIS de balises markdown (pas de \`\`\`json, pas de \`\`\`). Le premier caractère de ta réponse doit être { et le dernier }.`;

  let userPrompt = "";

  if (sequence === 1) {
    userPrompt = `Prépare la fiche de SÉQUENCE 1 (Installation des ressources) selon le manuel officiel APC de l'EEC pour :
- Titre : "${titre}"
- Référence : ${reference}
- Tranche d'âge : ${trancheLabel}
${contexteLecon ? `- Contexte : ${contexteLecon}` : ""}

RÈGLES STRICTES à respecter pour cette séquence :
- Situation de vie : 1-2 questions MAX (pas plus). Hypothèses non validées par le MCE à ce stade.
- Résumé : Génère un résumé (1/4 du texte, répondant à Qui/Fait quoi/Où/Quand/Comment/Avec quel effet) car ${trancheAge === "petits" ? "les petits ont besoin d'un résumé si plus de 3 versets" : trancheAge === "moyens" ? "les moyens ont besoin d'un résumé si plus de 5 versets" : "les grands ont besoin d'un résumé si plus de 10 versets"}.
- Exploitation du texte : questions progressives orientées UNIQUEMENT vers la compétence et le titre — pas une étude biblique.
- Retenons : Le MCE NE DONNE PAS le retenons. Il pose "À partir de toutes ces réponses, que retiens-tu de ce texte ?" et les enfants le construisent. Génère la réponse attendue des enfants.
- Message central : Le MCE NE LE DONNE PAS. Il pose "Dis ce que ce texte t'apporte de plus pour l'édification de ta foi chrétienne." La réponse attendue commence par "Pour l'édification de ma foi chrétienne, ce texte m'apprend que..."
- Élaboration : script LITTÉRAL mot à mot, comme si le MCE parlait devant les enfants (inclure les salutations, les transitions exactes, les formulations précises des questions).

Génère EXACTEMENT ce JSON :

{
  "competence": "Compétence en 1-2 phrases avec verbes d'action (formulée comme : Ce que l'enfant sera capable de faire)",
  "materielNecessaire": [
    "Bibles (version accessible)",
    "Tableau/ardoise + craie",
    "Matériel spécifique 1",
    "Matériel spécifique 2"
  ],
  "priere": {
    "ouverture": "Prière courte d'ouverture (3-4 phrases sincères, adaptées aux ${trancheLabel})",
    "finale": "Prière de fin de préparation — le MCE présente sa propre personne à Dieu par rapport à la leçon et supplie d'être capable de développer les savoir-être qu'il exigera aux enfants"
  },
  "chantsDeLouange": [
    {
      "titre": "Titre du chant en lien avec le thème",
      "paroles": "Refrain ou premier couplet complet"
    },
    {
      "titre": "Second chant en lien avec le thème",
      "paroles": "Refrain ou premier couplet complet"
    }
  ],
  "situationDeVie": {
    "contexte": "Cadre/milieu/lieu où se déroule la situation (quartier, marché, école, maison, église...)",
    "cible": "Personne ou personnage qui vit la situation (prénom + profil court)",
    "paradoxe": "L'élément qui sort de l'ordinaire, crée une tension et aiguise la curiosité de l'enfant",
    "tache": "Question affirmative/déclarative posée aux enfants pour dégager leurs hypothèses (ex: 'Formule une raison qui...' ou 'Dis ce qui peut...')",
    "histoire": "Historiette courte et vraisemblable (5-6 lignes max), vivante, proche du quotidien camerounais, se terminant par le paradoxe",
    "questions": [
      "Question 1 sur la situation (1 seule question supplémentaire MAX)"
    ]
  },
  "lectureEtResume": {
    "strategie": "Comment lire/faire lire le texte (ex: lecture à voix haute par un enfant chez les grands, résumé oral par le MCE chez les petits...)",
    "resume": "Résumé du texte en 3-4 lignes (1/4 du texte original) répondant à : Qui ? Fait quoi ? Où ? Quand ? Comment ? Avec quel effet ? — Sans opinions personnelles du MCE",
    "motsCles": [
      {"mot": "Terme clé 1 du texte", "definition": "Définition simple adaptée aux ${trancheLabel}"},
      {"mot": "Terme clé 2 du texte", "definition": "Définition simple"},
      {"mot": "Terme clé 3 du texte", "definition": "Définition simple"}
    ]
  },
  "exploitationTexte": {
    "noteMoniteur": "La Bible est FERMÉE pendant l'exploitation. Les questions permettent aux enfants de redire ce qu'ils ont entendu, orientées vers la compétence. PAS une étude biblique.",
    "questions": [
      {"question": "Question 1 de compréhension directe du récit (Qui ? Que fait ? Où ?)", "reponseAttendue": "Réponse précise tirée du texte/résumé"},
      {"question": "Question 2 sur les personnages et leurs actions", "reponseAttendue": "Réponse complète"},
      {"question": "Question 3 sur les conséquences ou les résultats (Quel est l'impact ? Que se passe-t-il ensuite ?)", "reponseAttendue": "Réponse développée"},
      {"question": "Question 4 orientée vers la compétence (lien entre le texte et la vie de l'enfant)", "reponseAttendue": "Réponse orientée compétence"}
    ],
    "questionRetenons": "À partir de toutes les réponses proposées, dis ce que tu retiens de notre texte/récit.",
    "reponseRetenons": "Ce que les enfants doivent ressortir ensemble comme retenons (synthèse des réponses à l'exploitation)",
    "questionMessageCentral": "Dis ce que ce texte t'apporte de plus pour l'édification de ta foi chrétienne.",
    "reponseMessageCentral": "Pour l'édification de ma foi chrétienne, ce texte m'apprend que... [vérité spirituelle profonde et spécifique à la leçon, 1-2 phrases]"
  },
  "retourSituationDeVie": "Comment le MCE revient à la situation de vie initiale pour valider ou invalider les hypothèses des enfants, en lumière de ce qu'ils ont découvert dans le texte",
  "elaboration": {
    "dureeTotal": "45-60 minutes",
    "scriptComplet": "Script LITTÉRAL complet de la présentation, mot à mot, incluant : les salutations, la présentation du titre et référence, la compétence, la situation de vie avec les questions, la lecture/résumé du texte, les questions d'exploitation une par une avec les réponses attendues, la question du retenons, la question du message central, le retour à la situation de vie, la conclusion et la prière finale. Rédige comme si le MCE parlait directement aux enfants (utilise 'les amis', 'mon ami...', 'très bien', 'merci', etc. comme dans l'exemple du manuel)."
  },
  "conseilsMoniteur": [
    "Conseil 1 : rappel sur le rôle du MCE (ne pas donner les réponses, laisser les enfants découvrir)",
    "Conseil 2 : astuce pratique spécifique à ce texte biblique",
    "Conseil 3 : comment gérer un enfant qui donne une mauvaise réponse (valoriser, recadrer avec douceur)",
    "Conseil 4 : erreur fréquente à éviter lors de la présentation de cette leçon"
  ]
}`;
  } else if (sequence === 2) {
    userPrompt = `Prépare la fiche de SÉQUENCE 2 (Évaluation sommative + Intégration + Liaison familiale) selon le manuel officiel APC de l'EEC pour :
- Titre : "${titre}"
- Référence : ${reference}
- Tranche d'âge : ${trancheLabel}
${contexteLecon ? `- Contexte : ${contexteLecon}` : ""}

RÈGLES STRICTES à respecter :
a) Évaluation sommative : (1) questions sur l'histoire/récit biblique, (2) question de révision du message central, (3) question d'application formulée EXACTEMENT ainsi : "À la lumière de [comportements/attitudes] de [personnages du texte] relevés dans la leçon, décris deux actions que tu vas mener afin de [compétence à développer]"
b) Intégration : activité à faire à la MAISON par l'enfant SEUL. Situation-problème MAX 6 lignes (contexte+cible+paradoxe+tâche). 2-3 questions MAX. La DERNIÈRE question débouche TOUJOURS sur une production pratique (dessin, affiche, chant, slogan) adaptée à l'âge. NB: les petits (Maternelle-CE1) ont une activité pratique tirée directement de la leçon.
c) Liaison familiale : structure officielle = résumé du récit biblique + message central et compétence à développer + discussion en famille (activité pratique avec les parents).
d) Le MCE explique l'intégration aux enfants, leur montre la page de la liaison familiale dans leur cahier, et explique au besoin.

Génère EXACTEMENT ce JSON :

{
  "priere": {
    "ouverture": "Prière courte d'ouverture (3-4 phrases, rappeler la leçon de la Séquence 1)",
    "finale": "Prière de clôture"
  },
  "rappelSequence1": {
    "instructionMCE": "Le MCE demande aux enfants de raconter l'histoire de la Séquence 1 en leurs propres termes — il NE raconte PAS lui-même",
    "questionsRappel": [
      "Question 1 de rappel rapide du récit (Qui se souvient du titre et de la référence ?)",
      "Question 2 de rappel du retenons",
      "Question 3 de rappel du message central"
    ]
  },
  "evaluationSommative": {
    "noteMoniteur": "Il ne s'agit PAS de raconter à nouveau l'histoire, mais de poser des questions pour vérifier la maîtrise du récit biblique, du retenons, des savoirs/savoir-faire/savoir-être",
    "questionsHistoire": [
      {"question": "Question 1 sur les faits du récit (personnages, actions, lieu)", "reponseAttendue": "Réponse précise tirée du texte"},
      {"question": "Question 2 sur les personnages et leurs comportements", "reponseAttendue": "Réponse précise"},
      {"question": "Question 3 sur les conséquences ou résultats dans le texte", "reponseAttendue": "Réponse complète"},
      {"question": "Question 4 (pour les grands uniquement si applicable) : question de compréhension approfondie", "reponseAttendue": "Réponse développée"}
    ],
    "questionMessageCentral": {
      "question": "Rappelle-nous le message central de notre leçon.",
      "reponseAttendue": "Pour l'édification de ma foi chrétienne, ce texte m'apprend que... [reformulation du message central]"
    },
    "questionApplication": "À la lumière de [comportements/attitudes spécifiques des personnages du texte ${reference}] relevés dans notre leçon, décris deux actions que tu vas mener afin de [compétence à développer liée à \"${titre}\"]"
  },
  "activiteIntegration": {
    "noteMoniteur": "C'est un travail INDIVIDUEL à faire à la MAISON. Le MCE explique clairement, s'assure que chaque enfant comprend et dispose du matériel nécessaire.",
    "situationProbleme": {
      "contexte": "Nouveau cadre/milieu différent de la Séquence 1 (toujours du quotidien camerounais : maison, école, quartier, église, marché...)",
      "cible": "Nouveau personnage fictif + son profil (prénom + âge + situation)",
      "paradoxe": "Nouveau problème qui nécessite de mobiliser les ressources de la leçon pour le résoudre",
      "tache": "Ce que l'enfant doit faire en tant qu'expert (formulé à la 2ème personne : 'En t'inspirant de... montre comment...' ou 'À l'exemple de... dis comment...')",
      "histoire": "Historiette complète MAX 6 lignes incluant contexte+cible+paradoxe+tâche, vivante et proche du vécu de l'enfant"
    },
    "questions": [
      {"question": "Question 1 : identifier/analyser le problème posé dans la situation", "reponseAttendue": "Ce que l'enfant doit identifier à partir de la situation"},
      {"question": "Question 2 : mobiliser les ressources de la leçon pour proposer une solution", "reponseAttendue": "Solution basée sur ce qui a été appris dans la leçon"},
      {"question": "Question 3 (PRODUCTION PRATIQUE — toujours en dernier) : Réalise [dessin / affiche / slogan / chant] qui montre [élément clé de la leçon]", "reponseAttendue": "Description de ce qu'une bonne production doit montrer"}
    ],
    "noteActivitePetits": "Pour les petits (Maternelle-CE1) : l'intégration est une activité pratique simple et concrète tirée directement de la leçon (coloriage, dessin guidé, reconstitution d'images...). Génère une version adaptée ici.",
    "activitePetits": "Description de l'activité pratique simplifiée pour les petits qui ne savent pas encore lire/écrire"
  },
  "liaisonFamiliale": {
    "noteMoniteur": "Le MCE précise la page de la liaison familiale dans le cahier de l'enfant et l'explique si nécessaire. C'est centré sur les PARENTS.",
    "resumeRecit": "Résumé du récit biblique de ${reference} en 4-5 lignes, clair et simple pour les parents qui n'étaient pas à la leçon",
    "messageCentralEtCompetence": "Message central + compétence à développer, formulés simplement pour les parents",
    "discussionEnFamille": [
      "Question de discussion en famille 1 (liée au quotidien camerounais, accessible à tous les parents)",
      "Question de discussion en famille 2 (pour approfondir)",
      "Activité pratique concrète à réaliser ensemble en famille en application de la leçon"
    ]
  },
  "elaboration": {
    "dureeTotal": "45-60 minutes",
    "scriptComplet": "Script LITTÉRAL complet de la présentation, mot à mot, incluant : accueil et rappel (demander aux enfants de raconter l'histoire), évaluation sommative question par question avec transitions naturelles, introduction de l'intégration et explication claire à voix haute, présentation de la liaison familiale aux enfants. Rédige comme si le MCE parlait directement aux enfants."
  },
  "conseilsMoniteur": [
    "Conseil 1 : ne pas raconter à nouveau l'histoire en Séquence 2 — demander aux enfants de le faire",
    "Conseil 2 : pour l'intégration, s'assurer que l'enfant comprend AVANT de rentrer chez lui",
    "Conseil 3 : être créatif sur la production pratique (ne pas toujours demander un dessin)",
    "Conseil 4 : pour les enfants qui ne savent pas lire/écrire, prévoir une activité adaptée"
  ]
}`;
  } else if (sequence === 3) {
    userPrompt = `Prépare la fiche de SÉQUENCE 3 (Vérification de l'intégration) selon le manuel officiel APC de l'EEC pour :
- Titre : "${titre}"
- Référence : ${reference}
- Tranche d'âge : ${trancheLabel}
${contexteLecon ? `- Contexte : ${contexteLecon}` : ""}

RÈGLES STRICTES à respecter pour cette séquence :
1. Le MCE partage EN PREMIER comment lui-même a mis en pratique la leçon (avant d'inviter les enfants à témoigner). La leçon doit d'abord transformer la vie du MCE.
2. Le MCE rappelle le titre, la référence, la compétence et le message central de la leçon.
3. Le MCE rappelle l'activité donnée en Séquence 2 (intégration) à tous les enfants.
4. Le MCE APPRÉCIE le travail des enfants (écoute, dit "bien", "passable", "oui très bien", "hmm c'est bon mais...") SANS JAMAIS DIRE CE QU'IL FALLAIT FAIRE — la correction appartient à la Séquence 4.
5. Le MCE RELÈVE et NOTE les difficultés rencontrées par les enfants — c'est la base de la préparation de la Séquence 4. Les difficultés peuvent être : compréhension du récit, formulation d'un slogan, réalisation d'une affiche, utilisation des savoirs pour résoudre le problème.
6. Le MCE vérifie aussi le travail de la liaison familiale (réactions/témoignages des enfants sur les discussions en famille).
7. Un dimanche ENTIER est consacré à cette séquence pour que le MAXIMUM d'enfants puissent intervenir.

Génère EXACTEMENT ce JSON :

{
  "priere": {
    "ouverture": "Prière d'ouverture du MCE (3-4 phrases — demander à l'Esprit de guider l'appréciation des travaux)",
    "finale": "Prière de clôture"
  },
  "partageMoniteur": {
    "noteImportante": "Le MCE PARTAGE EN PREMIER avant d'inviter les enfants. La leçon qu'il veut faire vivre aux enfants doit d'abord transformer sa propre vie.",
    "exempleTeemoignage": "Exemple concret et authentique de comment le MCE a vécu/appliqué la compétence de la leçon '${titre}' dans sa propre vie cette semaine (situation du quotidien camerounais, honnête et inspirant)",
    "difficultesHonnetes": "Difficulté que le MCE peut partager honnêtement sur sa propre mise en pratique (humaniser le témoignage, montrer que c'est normal d'avoir des difficultés)",
    "transitionVersEnfants": "Ce que le MCE dit pour inviter les enfants à partager après son témoignage"
  },
  "rappelLecon": {
    "elementsARappeler": [
      "Titre de la leçon : '${titre}'",
      "Référence biblique : ${reference}",
      "Compétence à développer",
      "Message central (Pour l'édification de ma foi chrétienne, ce texte m'apprend que...)"
    ],
    "rappelActiviteIntegration": "Le MCE rappelle exactement l'activité d'intégration donnée le dimanche précédent à tous les enfants"
  },
  "appreciationIntegration": {
    "regleFondamentale": "APPRÉCIER = écouter les réponses des enfants SANS dire ce qu'il fallait faire ou comment il fallait le faire — ça c'est le travail du dimanche 4 (Séquence 4).",
    "formulesDAppreciation": [
      "Formule d'appréciation positive : 'Bien !', 'Très bien !', 'Excellent !', 'Parfait !'",
      "Formule d'appréciation nuancée : 'Passable', 'C'est un bon début', 'Oui, pas exactement ça, mais tu es sur la bonne voie'",
      "Formule encourageante : 'Hmm, c'est un bon slogan mais ça ne montre pas encore [aspect de la compétence]'"
    ],
    "corrigeHarmonise": [
      {"question": "Question 1 de l'intégration (Séquence 2)", "reponseAttendue": "Corrigé type complet — réponse correcte harmonisée lors de la préparation collective"},
      {"question": "Question 2 de l'intégration", "reponseAttendue": "Corrigé type complet"},
      {"question": "Question 3 / Production pratique", "reponseAttendue": "Description de ce qu'une bonne production doit contenir — critères d'appréciation sans corriger directement"}
    ],
    "typesDesDifficultesARelever": [
      "Difficultés liées à la compréhension du récit biblique",
      "Difficultés liées à la formulation d'un slogan/affiche en lien avec la compétence",
      "Difficultés liées à l'utilisation des savoirs pour résoudre le problème posé",
      "Difficultés liées à la mobilisation ou sélection des ressources de la leçon",
      "Difficultés liées aux conditions familiales (ressources non disponibles, manque d'aide des parents)"
    ],
    "noteDifficultesPreparation4": "Le MCE doit OBLIGATOIREMENT noter ces difficultés — elles seront la BASE de la préparation de la Séquence 4"
  },
  "verificationLiaisonFamiliale": {
    "questionsVerification": [
      "Question pour savoir si l'enfant a fait la liaison familiale avec ses parents",
      "Question pour recueillir les réactions des parents aux questions de discussion",
      "Question pour savoir si l'activité pratique en famille a été réalisée"
    ],
    "noteVigilance": "Le MCE doit être attentif à tout détail alarmant dans le cahier de l'enfant qui nécessiterait d'interpeller ou d'exhorter les parents"
  },
  "elaboration": {
    "dureeTotal": "45-60 minutes (un dimanche entier pour cette séquence)",
    "scriptComplet": "Script LITTÉRAL complet de la présentation, mot à mot, incluant : accueil et prière, témoignage du MCE en premier avec transition vers les enfants, rappel du titre/référence/compétence/message central, rappel de l'activité d'intégration, appréciation des travaux enfant par enfant avec les formules appropriées, vérification de la liaison familiale, clôture. Rédige comme si le MCE parlait directement aux enfants — utiliser 'les amis', 'mon ami...', encourager la participation maximale."
  },
  "conseilsMoniteur": [
    "Conseil 1 : NE PAS corriger en Séquence 3 — apprécier seulement. La correction est pour la Séquence 4.",
    "Conseil 2 : noter méthodiquement TOUTES les difficultés observées — c'est la matière première de la Séquence 4",
    "Conseil 3 : donner la parole au MAXIMUM d'enfants — un dimanche entier est réservé pour cela",
    "Conseil 4 : comment gérer un enfant qui n'a pas fait l'intégration sans le culpabiliser"
  ]
}`;
  } else {
    userPrompt = `Prépare la fiche de SÉQUENCE 4 (Remédiation) selon le manuel officiel APC de l'EEC pour :
- Titre : "${titre}"
- Référence : ${reference}
- Tranche d'âge : ${trancheLabel}
${contexteLecon ? `- Contexte : ${contexteLecon}` : ""}

RÈGLES STRICTES à respecter pour cette séquence :
1. La Séquence 4 est une phase de CORRECTION — ce qui n'a pas été fait en Séquence 3 (qui était l'appréciation).
2. Le MCE rappelle le titre, la référence et la compétence à développer.
3. Le MCE ÉNONCE aux enfants les difficultés et problèmes relevés lors de la Séquence 3.
4. Le MCE PROPOSE les solutions aux manquements relevés.
5. Si possible, remédiation en PETITS GROUPES selon les difficultés : un groupe pour les enfants avec problème de compréhension du récit, un groupe pour la mobilisation des ressources, un groupe pour l'utilisation des ressources, etc.
6. Si l'effectif des MCE ne permet pas les groupes, résoudre tous les problèmes en groupe unique, un par un.
7. IMPORTANT : La remédiation est DIFFÉRENTE pour chaque lieu de culte selon les difficultés relevées localement — pas une remédiation uniforme.
8. Les solutions de remédiation peuvent être : refaire le récit biblique, expliquer comment élaborer un slogan/affiche, expliquer la technique d'identification et résolution d'un problème à partir de la leçon.

Génère EXACTEMENT ce JSON :

{
  "priere": {
    "ouverture": "Prière d'ouverture (3-4 phrases — demander la compréhension et la correction bienveillante)",
    "finale": "Prière de clôture et d'envoi"
  },
  "rappelLecon": {
    "titre": "${titre}",
    "reference": "${reference}",
    "competence": "Rappel de la compétence à développer de cette leçon",
    "messageCentral": "Rappel du message central : 'Pour l'édification de ma foi chrétienne, ce texte m'apprend que...'"
  },
  "difficultesRelevees": {
    "noteMoniteur": "Ces difficultés ont été relevées lors de la Séquence 3. Le MCE les communique clairement aux enfants avant de les corriger.",
    "typesFrequents": [
      {
        "type": "Difficulté 1 : problème de compréhension du récit biblique",
        "description": "Les enfants n'ont pas bien retenu les faits du récit de ${reference}",
        "groupeConcerne": "Groupe A — enfants qui n'ont pas pu répondre aux questions sur l'histoire"
      },
      {
        "type": "Difficulté 2 : problème de mobilisation des ressources",
        "description": "L'enfant connaît le récit mais n'arrive pas à l'utiliser pour résoudre le problème de l'intégration",
        "groupeConcerne": "Groupe B — enfants qui connaissent l'histoire mais n'arrivent pas à l'appliquer"
      },
      {
        "type": "Difficulté 3 : problème de production pratique (slogan, affiche, dessin)",
        "description": "L'enfant n'a pas su réaliser la production pratique demandée ou elle ne reflète pas la compétence",
        "groupeConcerne": "Groupe C — enfants dont la production ne correspond pas à la leçon"
      }
    ]
  },
  "groupesDeRemediation": [
    {
      "nomGroupe": "Groupe A — Remédiation sur le récit biblique",
      "difficulte": "Mauvaise maîtrise du récit de ${reference}",
      "solution": "Refaire le récit de manière simplifiée, avec questions courtes et réponses progressives",
      "activite": "Description détaillée de l'activité de remédiation pour ce groupe (refaire les questions clés du récit, utiliser des images ou gestes pour aider la mémorisation...)",
      "materiel": ["Matériel nécessaire pour ce groupe"]
    },
    {
      "nomGroupe": "Groupe B — Remédiation sur la mobilisation des ressources",
      "difficulte": "L'enfant connaît le récit mais ne sait pas utiliser les savoirs pour résoudre un problème",
      "solution": "Expliquer le lien entre ce que les personnages ont fait dans le texte et comment cela s'applique dans leur vie",
      "activite": "Description de l'activité : reprendre la situation-problème de l'intégration et guider l'enfant à identifier quelle ressource de la leçon correspond à chaque partie du problème",
      "materiel": ["Matériel nécessaire"]
    },
    {
      "nomGroupe": "Groupe C — Remédiation sur la production pratique",
      "difficulte": "L'enfant n'a pas su réaliser le slogan/affiche/dessin attendu",
      "solution": "Expliquer pas à pas comment construire le type de production demandé (ex: comment élaborer un slogan en 3 étapes : identifier le message, le formuler court, le rendre mémorable)",
      "activite": "Description de l'activité : montrer un exemple de bonne production, puis faire réaliser une nouvelle production améliorée par l'enfant",
      "materiel": ["Matériel nécessaire pour la production"]
    }
  ],
  "remediationGroupeUnique": {
    "note": "Si l'effectif des MCE ne permet pas les petits groupes, résoudre les difficultés en groupe unique, une par une",
    "ordreResolution": [
      "Étape 1 : énoncer la difficulté clairement et sans jugement",
      "Étape 2 : proposer la solution et l'expliquer simplement",
      "Étape 3 : faire pratiquer par les enfants immédiatement",
      "Étape 4 : valider la compréhension avant de passer à la difficulté suivante"
    ]
  },
  "recapitulatifCycle": {
    "noteMoniteur": "À la fin de la remédiation, faire un récapitulatif des 4 séquences pour clôturer le cycle de la leçon",
    "pointsCles": [
      "Point clé 1 : vérité biblique centrale de la leçon '${titre}' tirée de ${reference}",
      "Point clé 2 : compétence développée — ce que l'enfant sait maintenant faire",
      "Point clé 3 : engagement pratique que l'enfant emporte dans sa vie",
      "Point clé 4 : lien avec la communauté (Église, famille, école)"
    ],
    "messageFinal": "Message d'encouragement du MCE pour clôturer le cycle (valoriser les progrès, rappeler l'essentiel, envoyer les enfants avec un engagement concret)"
  },
  "elaboration": {
    "dureeTotal": "45-60 minutes",
    "scriptComplet": "Script LITTÉRAL complet de la présentation, mot à mot, incluant : accueil et prière, rappel du titre/référence/compétence, annonce des difficultés relevées en Séquence 3, remédiation groupe par groupe (ou en groupe unique) avec ce que le MCE dit exactement pour chaque correction, récapitulatif final du cycle des 4 séquences, prière de clôture et envoi. Rédige comme si le MCE parlait directement aux enfants."
  },
  "encouragements": "Message sincère et profond pour le MCE — reconnaître l'importance et la difficulté de la remédiation, rappeler que c'est l'étape qui fait la différence dans la vie des enfants, les encourager à ne pas baisser les bras (5-6 lignes, chaleureux et inspirants, en langage camerounais)",
  "conseilsMoniteur": [
    "Conseil 1 : énoncer les difficultés aux enfants SANS les nommer personnellement pour préserver leur dignité",
    "Conseil 2 : pour les petits groupes, s'assurer que chaque MCE a bien les difficultés ET les solutions de son groupe",
    "Conseil 3 : la remédiation n'est pas identique dans tous les lieux de culte — elle doit s'adapter aux difficultés locales",
    "Conseil 4 : si AUCUNE difficulté n'a été relevée en Séquence 3, cette séquence sera 'en chômage technique' — importance de bien relever les difficultés en Séquence 3"
  ]
}`;
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  let fullResponse = "";

  try {
    const stream = await openai.chat.completions.create({
      model: "gpt-4o",
      max_completion_tokens: 8192,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      stream: true,
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        fullResponse += content;
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
  } catch (err) {
    req.log.error({ err }, "Error generating lesson");
    res.write(`data: ${JSON.stringify({ error: "Erreur lors de la génération. Vérifiez votre connexion et réessayez." })}\n\n`);
  }

  res.end();
});

router.post("/lessons", async (req, res) => {
  const body = CreateLessonBody.parse(req.body);
  const [lesson] = await db
    .insert(lessonsTable)
    .values({
      titre: body.titre,
      reference: body.reference,
      trancheAge: body.trancheAge,
      sequence: body.sequence,
      contenu: body.contenu,
    })
    .returning();
  res.status(201).json({
    ...lesson,
    createdAt: lesson!.createdAt.toISOString(),
  });
});

router.get("/lessons/:id", async (req, res) => {
  const { id } = GetLessonParams.parse({ id: Number(req.params.id) });
  const [lesson] = await db
    .select()
    .from(lessonsTable)
    .where(eq(lessonsTable.id, id));
  if (!lesson) {
    res.status(404).json({ error: "Leçon introuvable" });
    return;
  }
  res.json({ ...lesson, createdAt: lesson.createdAt.toISOString() });
});

router.delete("/lessons/:id", async (req, res) => {
  const { id } = DeleteLessonParams.parse({ id: Number(req.params.id) });
  const [deleted] = await db
    .delete(lessonsTable)
    .where(eq(lessonsTable.id, id))
    .returning();
  if (!deleted) {
    res.status(404).json({ error: "Leçon introuvable" });
    return;
  }
  res.status(204).send();
});

export default router;
