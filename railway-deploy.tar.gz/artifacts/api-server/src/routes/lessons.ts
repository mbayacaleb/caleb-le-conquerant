import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { lessonsTable } from "@workspace/db";
import { desc, eq, count } from "drizzle-orm";
import {
  ListLessonsResponseItem,
  CreateLessonBody,
  GetLessonParams,
  DeleteLessonParams,
  GenerateLessonBody,
} from "@workspace/api-zod";
import { openai } from "@workspace/integrations-openai-ai-server";

const router: IRouter = Router();

router.get("/lessons", async (req, res) => {
  const lessons = await db
    .select()
    .from(lessonsTable)
    .orderBy(desc(lessonsTable.createdAt));
  const parsed = lessons.map((l) =>
    ListLessonsResponseItem.parse({
      id: l.id,
      titre: l.titre,
      reference: l.reference,
      trancheAge: l.trancheAge,
      sequence: l.sequence,
      contenu: l.contenu,
      createdAt: l.createdAt.toISOString(),
    })
  );
  res.json(parsed);
});

router.get("/lessons/stats", async (req, res) => {
  const all = await db.select().from(lessonsTable).orderBy(desc(lessonsTable.createdAt));

  const parSequence = { sequence1: 0, sequence2: 0, sequence3: 0, sequence4: 0 };
  const parTranche = { petits: 0, moyens: 0, grands: 0 };

  for (const l of all) {
    const key = `sequence${l.sequence}` as keyof typeof parSequence;
    if (key in parSequence) parSequence[key]++;
    const ta = l.trancheAge as keyof typeof parTranche;
    if (ta in parTranche) parTranche[ta]++;
  }

  const recentes = all.slice(0, 5).map((l) => ({
    id: l.id,
    titre: l.titre,
    reference: l.reference,
    trancheAge: l.trancheAge,
    sequence: l.sequence,
    contenu: l.contenu,
    createdAt: l.createdAt.toISOString(),
  }));

  res.json({
    total: all.length,
    parSequence,
    parTranche,
    recentes,
  });
});

router.post("/lessons/generate", async (req, res) => {
  const body = GenerateLessonBody.parse(req.body);
  const { titre, reference, trancheAge, sequence, contexteLecon } = body;

  const trancheLabel = trancheAge === "petits" ? "petits (maternelle à CE1)" : trancheAge === "moyens" ? "moyens (CE2 à CM1)" : "grands (CM2 et plus)";

  const systemPrompt = `Tu es un expert en pédagogie chrétienne pour enfants selon l'Approche par Compétence (APC) de l'Église Évangélique du Cameroun (EEC). 
Tu prépares des leçons pour le Culte d'Enfants selon le manuel de référence APC.
Réponds toujours en français avec un langage adapté aux ${trancheLabel}.
Génère du contenu structuré, pratique et fidèle aux Écritures.`;

  let userPrompt = "";

  if (sequence === 1) {
    userPrompt = `Prépare la SÉQUENCE 1 (Installation des ressources) pour la leçon suivante:
- Titre: "${titre}"
- Référence biblique: ${reference}
- Tranche d'âge: ${trancheLabel}
${contexteLecon ? `- Contexte supplémentaire: ${contexteLecon}` : ""}

Génère exactement ces sections dans cet ordre (en JSON structuré):

{
  "competence": "Compétence à développer chez l'enfant (1-2 phrases avec verbes d'action)",
  "situationDeVie": {
    "contexte": "Le contexte de l'histoire",
    "cible": "Le/les personnage(s) qui vivent la situation",
    "paradoxe": "Le problème ou obstacle qui génère la curiosité",
    "tache": "La question posée aux enfants",
    "histoire": "L'histoire complète (4-6 lignes maximum)",
    "questions": ["Question 1 pour les enfants", "Question 2 (optionnelle)"]
  },
  "exploitationTexte": {
    "questions": [
      {"question": "...", "reponseAttendue": "..."},
      {"question": "...", "reponseAttendue": "..."},
      {"question": "...", "reponseAttendue": "..."}
    ]
  },
  "retenons": "Ce que l'enfant tire du texte (formule simple et mémorisable)",
  "messageCentral": "Pour l'édification de ma foi chrétienne, ce texte m'apprend que...",
  "elaboration": "Déroulé complet de la leçon du début à la fin (présentation détaillée)"
}

Réponds UNIQUEMENT avec le JSON valide, sans texte supplémentaire.`;
  } else if (sequence === 2) {
    userPrompt = `Prépare la SÉQUENCE 2 (Évaluation sommative, intégration et liaison familiale) pour la leçon:
- Titre: "${titre}"
- Référence biblique: ${reference}
- Tranche d'âge: ${trancheLabel}
${contexteLecon ? `- Contexte supplémentaire: ${contexteLecon}` : ""}

Génère exactement ce JSON structuré:

{
  "evaluationSommative": {
    "questionsHistoire": [
      {"question": "...", "reponseAttendue": "..."},
      {"question": "...", "reponseAttendue": "..."},
      {"question": "...", "reponseAttendue": "..."}
    ],
    "questionMessageCentral": {"question": "...", "reponseAttendue": "..."},
    "questionApplication": "À la lumière de... décris deux actions que tu vas mener afin de..."
  },
  "activiteIntegration": {
    "situationProbleme": {
      "contexte": "Contexte de la situation",
      "cible": "Qui vit la situation",
      "paradoxe": "Le problème posé",
      "tache": "Ce que l'enfant doit faire",
      "histoire": "L'histoire complète (6 lignes max)"
    },
    "questions": [
      {"question": "...", "guidanceReponse": "..."},
      {"question": "...", "guidanceReponse": "..."},
      {"question": "Application pratique (dessin, affiche, chant, slogan...)", "guidanceReponse": "..."}
    ]
  },
  "liaisonFamiliale": {
    "resumeRecit": "Résumé du récit biblique pour les parents",
    "messageCentralEtCompetence": "Message central et compétences à développer",
    "discussionEnFamille": [
      "Question de discussion 1",
      "Question de discussion 2",
      "Activité pratique en famille"
    ]
  }
}

Réponds UNIQUEMENT avec le JSON valide, sans texte supplémentaire.`;
  } else if (sequence === 3) {
    userPrompt = `Prépare la SÉQUENCE 3 (Préparation de la vérification des intégrations) pour la leçon:
- Titre: "${titre}"
- Référence biblique: ${reference}
- Tranche d'âge: ${trancheLabel}
${contexteLecon ? `- Contexte supplémentaire: ${contexteLecon}` : ""}

Génère exactement ce JSON structuré:

{
  "partageMoniteur": {
    "description": "Comment le moniteur a mis en pratique la leçon dans sa propre vie",
    "exemples": ["Exemple de mise en pratique 1", "Exemple de mise en pratique 2"],
    "difficultes": ["Difficulté possible 1", "Difficulté possible 2"]
  },
  "verificationIntegrations": {
    "corrigeIntegration": [
      {"question": "Question 1 de l'intégration", "reponseAttendue": "Réponse complète attendue"},
      {"question": "Question 2 de l'intégration", "reponseAttendue": "Réponse complète attendue"},
      {"question": "Question 3 (pratique)", "reponseAttendue": "Description de l'activité attendue"}
    ],
    "criteresEvaluation": ["Critère 1", "Critère 2", "Critère 3"]
  },
  "liaisonFamilialeVerification": {
    "questionsDiscussion": ["Question 1", "Question 2"],
    "activitePratique": "Description de l'activité pratique en famille"
  },
  "pointsAttention": ["Point d'attention 1", "Point d'attention 2"]
}

Réponds UNIQUEMENT avec le JSON valide, sans texte supplémentaire.`;
  } else {
    userPrompt = `Prépare la SÉQUENCE 4 (Préparation de la Remédiation) pour la leçon:
- Titre: "${titre}"
- Référence biblique: ${reference}
- Tranche d'âge: ${trancheLabel}
${contexteLecon ? `- Contexte supplémentaire: ${contexteLecon}` : ""}

Génère exactement ce JSON structuré:

{
  "difficultesCourantes": [
    {
      "difficulte": "Description de la difficulté observée",
      "cause": "Cause probable",
      "solutionRemediation": "Solution concrète pour remédier"
    },
    {
      "difficulte": "Autre difficulté fréquente",
      "cause": "Cause probable",
      "solutionRemediation": "Solution concrète"
    },
    {
      "difficulte": "Troisième difficulté",
      "cause": "Cause probable",
      "solutionRemediation": "Solution concrète"
    }
  ],
  "methodesRemediation": [
    {
      "methode": "Nom de la méthode",
      "description": "Comment l'appliquer",
      "materielNecessaire": ["Matériel 1", "Matériel 2"]
    },
    {
      "methode": "Deuxième méthode",
      "description": "Comment l'appliquer",
      "materielNecessaire": ["Matériel 1"]
    }
  ],
  "recapitulatifLecon": {
    "messageCentral": "Message central de la leçon",
    "competenceVisee": "Compétence à développer",
    "pointsCles": ["Point clé 1", "Point clé 2", "Point clé 3"]
  },
  "encouragements": "Message d'encouragement pour les moniteurs et les enfants"
}

Réponds UNIQUEMENT avec le JSON valide, sans texte supplémentaire.`;
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  let fullResponse = "";

  try {
    const stream = await openai.chat.completions.create({
      model: "gpt-5.4",
      max_completion_tokens: 8192,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      stream: true,
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        fullResponse += content;
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
  } catch (err) {
    req.log.error({ err }, "Error generating lesson");
    res.write(`data: ${JSON.stringify({ error: "Erreur lors de la génération" })}\n\n`);
  }

  res.end();
});

router.post("/lessons", async (req, res) => {
  const body = CreateLessonBody.parse(req.body);
  const [lesson] = await db
    .insert(lessonsTable)
    .values({
      titre: body.titre,
      reference: body.reference,
      trancheAge: body.trancheAge,
      sequence: body.sequence,
      contenu: body.contenu,
    })
    .returning();
  res.status(201).json({
    ...lesson,
    createdAt: lesson!.createdAt.toISOString(),
  });
});

router.get("/lessons/:id", async (req, res) => {
  const { id } = GetLessonParams.parse({ id: Number(req.params.id) });
  const [lesson] = await db
    .select()
    .from(lessonsTable)
    .where(eq(lessonsTable.id, id));
  if (!lesson) {
    res.status(404).json({ error: "Leçon introuvable" });
    return;
  }
  res.json({ ...lesson, createdAt: lesson.createdAt.toISOString() });
});

router.delete("/lessons/:id", async (req, res) => {
  const { id } = DeleteLessonParams.parse({ id: Number(req.params.id) });
  const [deleted] = await db
    .delete(lessonsTable)
    .where(eq(lessonsTable.id, id))
    .returning();
  if (!deleted) {
    res.status(404).json({ error: "Leçon introuvable" });
    return;
  }
  res.status(204).send();
});

export default router;
