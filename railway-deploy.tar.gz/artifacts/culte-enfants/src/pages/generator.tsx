import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";
import { Sparkles, Save, RefreshCw, ChevronDown, ChevronUp, BookOpen, Users, Layers } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useCreateLesson, getListLessonsQueryKey, getGetLessonsStatsQueryKey } from "@workspace/api-client-react";

const formSchema = z.object({
  titre: z.string().min(2, "Le titre est requis"),
  reference: z.string().min(2, "La référence biblique est requise"),
  trancheAge: z.enum(["petits", "moyens", "grands"]),
  sequence: z.enum(["1", "2", "3", "4"]),
  contexteLecon: z.string().optional(),
});
type FormValues = z.infer<typeof formSchema>;

const SEQUENCES = [
  { value: "1", label: "Séquence 1", sub: "Installation des ressources", color: "#3b82f6", bg: "#eff6ff", border: "#bfdbfe" },
  { value: "2", label: "Séquence 2", sub: "Évaluation & intégration", color: "#16a34a", bg: "#f0fdf4", border: "#bbf7d0" },
  { value: "3", label: "Séquence 3", sub: "Vérification des intégrations", color: "#d97706", bg: "#fffbeb", border: "#fde68a" },
  { value: "4", label: "Séquence 4", sub: "Remédiation", color: "#dc2626", bg: "#fef2f2", border: "#fecaca" },
];
const AGE_GROUPS = [
  { value: "petits", label: "Petits", sub: "Maternelle – CE1", icon: "👶" },
  { value: "moyens", label: "Moyens", sub: "CE2 – CM1", icon: "🧒" },
  { value: "grands", label: "Grands", sub: "CM2 et plus", icon: "👦" },
];

type D = Record<string, unknown>;
function str(v: unknown): string { return typeof v === "string" ? v : String(v ?? ""); }
function arr<T>(v: unknown): T[] { return Array.isArray(v) ? (v as T[]) : []; }
function obj(v: unknown): D { return (v != null && typeof v === "object" && !Array.isArray(v)) ? (v as D) : {}; }
function has(v: unknown): boolean { return v != null && v !== "" && !(Array.isArray(v) && v.length === 0); }

function SectionCard({ title, children, expanded, onToggle, accent }: { title: string; children: React.ReactNode; expanded: boolean; onToggle: () => void; accent?: string }) {
  return (
    <div className="border border-border rounded-xl overflow-hidden bg-card shadow-sm">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between px-5 py-4 text-left hover:bg-muted/40 transition-colors"
      >
        <div className="flex items-center gap-3">
          {accent && <div className="w-1 h-5 rounded-full shrink-0" style={{ background: accent }} />}
          <span className="font-semibold text-foreground">{title}</span>
        </div>
        {expanded ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
      </button>
      {expanded && <div className="px-5 pb-5 pt-1">{children}</div>}
    </div>
  );
}

function Section1({ data }: { data: D }) {
  const [exp, setExp] = useState<D>({ competence: true, sdv: true, et: true, retenons: true, mc: true, elab: false });
  const t = (k: string) => setExp(p => ({ ...p, [k]: !p[k] }));
  const sdv = obj(data.situationDeVie);
  const et = obj(data.exploitationTexte);
  const etQs = arr<{ question: string; reponseAttendue: string }>(et.questions);
  const sdvQs = arr<string>(sdv.questions);
  const blue = "#3b82f6";
  return (
    <div className="space-y-3">
      {has(data.competence) && (
        <SectionCard title="Compétence à développer" expanded={!!exp.competence} onToggle={() => t("competence")} accent={blue}>
          <p className="text-foreground leading-relaxed text-sm">{str(data.competence)}</p>
        </SectionCard>
      )}
      {has(data.situationDeVie) && (
        <SectionCard title="Situation de vie" expanded={!!exp.sdv} onToggle={() => t("sdv")} accent={blue}>
          <div className="space-y-3">
            <div className="bg-blue-50 border border-blue-100 rounded-xl p-4">
              <p className="text-foreground leading-relaxed italic text-sm">{str(sdv.histoire)}</p>
            </div>
            {sdvQs.length > 0 && <div><p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Questions pour les enfants</p>{sdvQs.map((q, i) => <p key={i} className="text-foreground text-sm py-1 border-b border-border last:border-0">→ {q}</p>)}</div>}
            <div className="grid grid-cols-2 gap-3">
              {has(sdv.contexte) && <Chip label="Contexte" value={str(sdv.contexte)} />}
              {has(sdv.cible) && <Chip label="Cible" value={str(sdv.cible)} />}
              {has(sdv.paradoxe) && <Chip label="Paradoxe" value={str(sdv.paradoxe)} />}
              {has(sdv.tache) && <Chip label="Tâche" value={str(sdv.tache)} />}
            </div>
          </div>
        </SectionCard>
      )}
      {etQs.length > 0 && (
        <SectionCard title="Exploitation du texte" expanded={!!exp.et} onToggle={() => t("et")} accent={blue}>
          <div className="space-y-2">
            {etQs.map((q, i) => (
              <div key={i} className="border border-border rounded-lg p-3 hover:bg-muted/30 transition-colors">
                <p className="font-medium text-foreground text-sm">Q{i + 1} : {q.question}</p>
                <p className="text-xs text-muted-foreground mt-1 pl-2 border-l-2 border-blue-200">→ {q.reponseAttendue}</p>
              </div>
            ))}
          </div>
        </SectionCard>
      )}
      {has(data.retenons) && (
        <SectionCard title="Retenons" expanded={!!exp.retenons} onToggle={() => t("retenons")} accent={blue}>
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
            <p className="text-foreground font-semibold leading-relaxed text-sm">{str(data.retenons)}</p>
          </div>
        </SectionCard>
      )}
      {has(data.messageCentral) && (
        <SectionCard title="Message Central" expanded={!!exp.mc} onToggle={() => t("mc")} accent={blue}>
          <div className="bg-primary/5 border-l-4 rounded-r-xl p-4" style={{ borderColor: blue }}>
            <p className="text-foreground italic leading-relaxed text-sm">{str(data.messageCentral)}</p>
          </div>
        </SectionCard>
      )}
      {has(data.elaboration) && (
        <SectionCard title="Élaboration complète" expanded={!!exp.elab} onToggle={() => t("elab")} accent={blue}>
          <p className="text-foreground leading-relaxed whitespace-pre-wrap text-sm">{str(data.elaboration)}</p>
        </SectionCard>
      )}
    </div>
  );
}

function Section2({ data }: { data: D }) {
  const [exp, setExp] = useState<D>({ ev: true, ai: true, lf: true });
  const t = (k: string) => setExp(p => ({ ...p, [k]: !p[k] }));
  const ev = obj(data.evaluationSommative);
  const ai = obj(data.activiteIntegration);
  const lf = obj(data.liaisonFamiliale);
  const evQs = arr<{ question: string; reponseAttendue: string }>(ev.questionsHistoire);
  const aiQs = arr<{ question: string; guidanceReponse: string }>(ai.questions);
  const aiSp = obj(ai.situationProbleme);
  const qmc = ev.questionMessageCentral as { question: string; reponseAttendue: string } | undefined;
  const lfDisc = arr<string>(lf.discussionEnFamille);
  const green = "#16a34a";
  return (
    <div className="space-y-3">
      {has(data.evaluationSommative) && (
        <SectionCard title="Évaluation sommative" expanded={!!exp.ev} onToggle={() => t("ev")} accent={green}>
          <div className="space-y-2">
            {evQs.map((q, i) => (
              <div key={i} className="border border-border rounded-lg p-3 hover:bg-muted/30 transition-colors">
                <p className="font-medium text-foreground text-sm">Q{i + 1} : {q.question}</p>
                <p className="text-xs text-muted-foreground mt-1 pl-2 border-l-2 border-green-200">→ {q.reponseAttendue}</p>
              </div>
            ))}
            {qmc != null && <div className="border border-green-200 rounded-lg p-3 bg-green-50"><p className="text-xs font-semibold text-green-700 mb-1">MESSAGE CENTRAL</p><p className="font-medium text-foreground text-sm">{qmc.question}</p><p className="text-xs text-muted-foreground mt-1">→ {qmc.reponseAttendue}</p></div>}
            {has(ev.questionApplication) && <div className="border border-green-200 rounded-lg p-3 bg-green-50/50"><p className="text-xs font-semibold text-green-700 mb-1">APPLICATION</p><p className="text-foreground text-sm">{str(ev.questionApplication)}</p></div>}
          </div>
        </SectionCard>
      )}
      {has(data.activiteIntegration) && (
        <SectionCard title="Activité d'intégration" expanded={!!exp.ai} onToggle={() => t("ai")} accent={green}>
          <div className="space-y-3">
            {has(ai.situationProbleme) && <div className="bg-green-50 border border-green-100 rounded-xl p-4"><p className="text-foreground italic leading-relaxed text-sm">{str(aiSp.histoire)}</p>{has(aiSp.tache) && <p className="text-xs text-muted-foreground mt-2">Tâche : {str(aiSp.tache)}</p>}</div>}
            {aiQs.map((q, i) => <div key={i} className="border border-border rounded-lg p-3"><p className="font-medium text-foreground text-sm">Q{i + 1} : {q.question}</p><p className="text-xs text-muted-foreground mt-1 pl-2 border-l-2 border-green-200">→ {q.guidanceReponse}</p></div>)}
          </div>
        </SectionCard>
      )}
      {has(data.liaisonFamiliale) && (
        <SectionCard title="Liaison familiale" expanded={!!exp.lf} onToggle={() => t("lf")} accent={green}>
          <div className="space-y-3">
            {has(lf.resumeRecit) && <div><p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Résumé du récit</p><p className="text-foreground text-sm leading-relaxed">{str(lf.resumeRecit)}</p></div>}
            {has(lf.messageCentralEtCompetence) && <div><p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Message central</p><p className="text-foreground text-sm">{str(lf.messageCentralEtCompetence)}</p></div>}
            {lfDisc.length > 0 && <div><p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Discussion en famille</p>{lfDisc.map((d, i) => <p key={i} className="text-foreground text-sm py-1">• {d}</p>)}</div>}
          </div>
        </SectionCard>
      )}
    </div>
  );
}

function Section3({ data }: { data: D }) {
  const pm = obj(data.partageMoniteur);
  const vi = obj(data.verificationIntegrations);
  const viQs = arr<{ question: string; reponseAttendue: string }>(vi.corrigeIntegration);
  const pts = arr<string>(data.pointsAttention);
  const amber = "#d97706";
  return (
    <div className="space-y-3">
      {has(data.partageMoniteur) && (
        <SectionCard title="Partage du moniteur" expanded={true} onToggle={() => {}} accent={amber}>
          {has(pm.description) && <p className="text-foreground leading-relaxed text-sm">{str(pm.description)}</p>}
          {arr<string>(pm.exemples).length > 0 && <div className="mt-2"><p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Exemples</p>{arr<string>(pm.exemples).map((e, i) => <p key={i} className="text-foreground text-sm">• {e}</p>)}</div>}
        </SectionCard>
      )}
      {viQs.length > 0 && (
        <SectionCard title="Corrigé de l'intégration" expanded={true} onToggle={() => {}} accent={amber}>
          <div className="space-y-2">{viQs.map((q, i) => <div key={i} className="border border-border rounded-lg p-3"><p className="font-medium text-foreground text-sm">Q{i + 1} : {q.question}</p><p className="text-xs text-muted-foreground mt-1 pl-2 border-l-2 border-amber-200">→ {q.reponseAttendue}</p></div>)}</div>
        </SectionCard>
      )}
      {pts.length > 0 && (
        <SectionCard title="Points d'attention" expanded={true} onToggle={() => {}} accent={amber}>
          <div className="space-y-2">{pts.map((p, i) => <div key={i} className="flex gap-2 items-start p-2 bg-amber-50 rounded-lg border border-amber-100"><span className="text-amber-600 font-bold text-sm shrink-0">!</span><p className="text-foreground text-sm">{p}</p></div>)}</div>
        </SectionCard>
      )}
    </div>
  );
}

function Section4({ data }: { data: D }) {
  const diffs = arr<{ difficulte: string; cause: string; solutionRemediation: string }>(data.difficultesCourantes);
  const meths = arr<{ methode: string; description: string; materielNecessaire: string[] }>(data.methodesRemediation);
  const rl = obj(data.recapitulatifLecon);
  const red = "#dc2626";
  return (
    <div className="space-y-3">
      {diffs.length > 0 && (
        <SectionCard title="Difficultés et remédiations" expanded={true} onToggle={() => {}} accent={red}>
          <div className="space-y-3">
            {diffs.map((d, i) => (
              <div key={i} className="border border-border rounded-xl p-4 space-y-2">
                <p className="font-semibold text-foreground text-sm">Difficulté {i + 1} : {d.difficulte}</p>
                <p className="text-xs text-muted-foreground bg-muted/50 rounded px-2 py-1">Cause : {d.cause}</p>
                <div className="bg-green-50 border border-green-200 rounded-lg p-3"><p className="text-xs font-semibold text-green-700 mb-0.5">SOLUTION</p><p className="text-sm text-green-800">{d.solutionRemediation}</p></div>
              </div>
            ))}
          </div>
        </SectionCard>
      )}
      {meths.length > 0 && (
        <SectionCard title="Méthodes de remédiation" expanded={true} onToggle={() => {}} accent={red}>
          <div className="space-y-2">{meths.map((m, i) => <div key={i} className="border border-border rounded-lg p-3"><p className="font-semibold text-foreground text-sm">{m.methode}</p><p className="text-xs text-muted-foreground mt-1">{m.description}</p>{m.materielNecessaire?.length > 0 && <p className="text-xs text-muted-foreground mt-1">Matériel : {m.materielNecessaire.join(", ")}</p>}</div>)}</div>
        </SectionCard>
      )}
      {has(data.recapitulatifLecon) && (
        <SectionCard title="Récapitulatif de la leçon" expanded={true} onToggle={() => {}} accent={red}>
          <div className="space-y-2">
            {has(rl.messageCentral) && <div className="bg-primary/5 border-l-4 border-primary/30 rounded-r-xl p-4"><p className="italic text-foreground text-sm">{str(rl.messageCentral)}</p></div>}
            {has(rl.competenceVisee) && <p className="text-foreground text-sm"><span className="font-semibold">Compétence :</span> {str(rl.competenceVisee)}</p>}
          </div>
        </SectionCard>
      )}
      {has(data.encouragements) && (
        <div className="rounded-xl p-5 text-center" style={{ background: "linear-gradient(135deg, hsl(220 55% 30% / 0.06) 0%, hsl(43 88% 52% / 0.08) 100%)", border: "1px solid hsl(220 55% 30% / 0.15)" }}>
          <p className="text-foreground italic leading-relaxed text-sm">{str(data.encouragements)}</p>
        </div>
      )}
    </div>
  );
}

function Chip({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-muted/60 rounded-lg p-3">
      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{label}</p>
      <p className="text-foreground text-sm mt-0.5 font-medium">{value}</p>
    </div>
  );
}

function renderContent(sequence: number, data: D) {
  if (sequence === 1) return <Section1 data={data} />;
  if (sequence === 2) return <Section2 data={data} />;
  if (sequence === 3) return <Section3 data={data} />;
  if (sequence === 4) return <Section4 data={data} />;
  return null;
}

export default function GeneratorPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [generating, setGenerating] = useState(false);
  const [parsedData, setParsedData] = useState<D | null>(null);
  const [generationError, setGenerationError] = useState("");
  const [lastForm, setLastForm] = useState<FormValues | null>(null);
  const createLesson = useCreateLesson();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { titre: "", reference: "", trancheAge: "moyens", sequence: "1", contexteLecon: "" },
  });

  const watchSeq = form.watch("sequence");
  const watchAge = form.watch("trancheAge");
  const currentSeq = SEQUENCES.find(s => s.value === watchSeq)!;

  async function onSubmit(values: FormValues) {
    setGenerating(true);
    setParsedData(null);
    setGenerationError("");
    setLastForm(values);
    try {
      const BASE = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");
      const response = await fetch(`${BASE}/api/lessons/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ titre: values.titre, reference: values.reference, trancheAge: values.trancheAge, sequence: parseInt(values.sequence), contexteLecon: values.contexteLecon || undefined }),
      });
      if (!response.body) throw new Error("Pas de réponse");
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let accumulated = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const evt = JSON.parse(line.slice(6));
              if (evt.content) { accumulated += evt.content; try { setParsedData(JSON.parse(accumulated)); } catch {} }
              if (evt.done) { setGenerating(false); try { setParsedData(JSON.parse(accumulated)); } catch { setGenerationError("Réponse invalide. Réessayez."); } }
              if (evt.error) { setGenerationError(evt.error); setGenerating(false); }
            } catch {}
          }
        }
      }
    } catch { setGenerationError("Erreur de connexion. Veuillez réessayer."); setGenerating(false); }
  }

  async function handleSave() {
    if (!parsedData || !lastForm) return;
    try {
      const lesson = await createLesson.mutateAsync({ data: { titre: lastForm.titre, reference: lastForm.reference, trancheAge: lastForm.trancheAge, sequence: parseInt(lastForm.sequence), contenu: JSON.stringify(parsedData) } });
      await queryClient.invalidateQueries({ queryKey: getListLessonsQueryKey() });
      await queryClient.invalidateQueries({ queryKey: getGetLessonsStatsQueryKey() });
      toast({ title: "Leçon sauvegardée", description: "Retrouvez-la dans Mes Leçons." });
      setLocation(`/lecon/${lesson.id}`);
    } catch { toast({ title: "Erreur", description: "Impossible de sauvegarder.", variant: "destructive" }); }
  }

  return (
    <div className="space-y-8">

      {/* Page header */}
      <div className="relative rounded-2xl overflow-hidden p-7 text-white shadow-lg"
        style={{ background: "linear-gradient(135deg, hsl(220 55% 28%) 0%, hsl(220 55% 20%) 100%)" }}>
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: "radial-gradient(circle at 80% 20%, white 1px, transparent 1px), radial-gradient(circle at 20% 80%, white 1px, transparent 1px)",
          backgroundSize: "40px 40px"
        }} />
        <div className="relative flex flex-col md:flex-row items-start md:items-center gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="h-5 w-5" style={{ color: "hsl(43 88% 65%)" }} />
              <p className="text-xs font-bold uppercase tracking-widest" style={{ color: "hsl(43 88% 65%)" }}>
                IA — Approche par Compétence
              </p>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold leading-tight mb-1">Préparer une leçon</h1>
            <p className="text-white/65 text-sm">
              Renseignez les informations ci-dessous. L'IA génère votre fiche de préparation complète en quelques secondes.
            </p>
          </div>
          <img src="/logo.jpg" alt="Logo" className="w-16 h-16 rounded-xl object-cover border-2 border-white/20 shadow-lg hidden md:block" />
        </div>
      </div>

      {/* Form card */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">

        {/* Séquence picker */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0" style={{ background: "hsl(220 55% 30% / 0.1)" }}>
              <Layers className="h-4 w-4" style={{ color: "hsl(220 55% 30%)" }} />
            </div>
            <p className="font-semibold text-foreground text-sm">Choisir la séquence</p>
          </div>
          <Form {...form}>
            <FormField control={form.control} name="sequence" render={({ field }) => (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {SEQUENCES.map(seq => (
                  <button
                    key={seq.value}
                    type="button"
                    onClick={() => field.onChange(seq.value)}
                    className="rounded-xl p-3 border-2 text-left transition-all cursor-pointer"
                    style={field.value === seq.value
                      ? { background: seq.bg, borderColor: seq.color, boxShadow: `0 0 0 1px ${seq.color}` }
                      : { background: "transparent", borderColor: "hsl(var(--border))" }
                    }
                  >
                    <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white mb-2" style={{ background: seq.color }}>{seq.value}</div>
                    <p className="font-semibold text-xs text-foreground leading-tight">{seq.label}</p>
                    <p className="text-xs text-muted-foreground mt-0.5 leading-tight">{seq.sub}</p>
                  </button>
                ))}
              </div>
            )} />
          </Form>
        </div>

        {/* Age group picker */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0" style={{ background: "hsl(220 55% 30% / 0.1)" }}>
              <Users className="h-4 w-4" style={{ color: "hsl(220 55% 30%)" }} />
            </div>
            <p className="font-semibold text-foreground text-sm">Tranche d'âge</p>
          </div>
          <Form {...form}>
            <FormField control={form.control} name="trancheAge" render={({ field }) => (
              <div className="grid grid-cols-3 gap-3">
                {AGE_GROUPS.map(ag => (
                  <button
                    key={ag.value}
                    type="button"
                    onClick={() => field.onChange(ag.value)}
                    className="rounded-xl p-4 border-2 text-center transition-all cursor-pointer"
                    style={field.value === ag.value
                      ? { background: "hsl(220 55% 30% / 0.08)", borderColor: "hsl(220 55% 30%)", boxShadow: "0 0 0 1px hsl(220 55% 30%)" }
                      : { background: "transparent", borderColor: "hsl(var(--border))" }
                    }
                  >
                    <p className="text-2xl mb-1">{ag.icon}</p>
                    <p className="font-semibold text-sm text-foreground">{ag.label}</p>
                    <p className="text-xs text-muted-foreground">{ag.sub}</p>
                  </button>
                ))}
              </div>
            )} />
          </Form>
        </div>

        {/* Lesson info */}
        <div className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0" style={{ background: "hsl(220 55% 30% / 0.1)" }}>
              <BookOpen className="h-4 w-4" style={{ color: "hsl(220 55% 30%)" }} />
            </div>
            <p className="font-semibold text-foreground text-sm">Informations de la leçon</p>
          </div>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="titre" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium">Titre de la leçon</FormLabel>
                    <FormControl><Input placeholder="Ex: La foi d'Abraham" data-testid="input-titre" className="h-11" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="reference" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium">Référence biblique</FormLabel>
                    <FormControl><Input placeholder="Ex: Genèse 22:1-18" data-testid="input-reference" className="h-11" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <FormField control={form.control} name="contexteLecon" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium">Contexte supplémentaire <span className="text-muted-foreground font-normal">(optionnel)</span></FormLabel>
                  <FormControl><Textarea placeholder="Notes particulières, contexte local, thème du mois..." className="resize-none" rows={2} data-testid="textarea-contexte" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              {/* CTA */}
              <div className="flex items-center gap-4 pt-2">
                <button
                  type="submit"
                  disabled={generating}
                  className="flex items-center gap-2.5 px-6 py-3 rounded-xl font-semibold text-sm text-white transition-all disabled:opacity-60 disabled:cursor-not-allowed shadow-md hover:shadow-lg active:scale-95"
                  style={{ background: generating ? "hsl(220 55% 38%)" : "hsl(220 55% 28%)" }}
                  data-testid="button-generate"
                >
                  {generating
                    ? <><RefreshCw className="h-4 w-4 animate-spin" />Génération en cours...</>
                    : <><Sparkles className="h-4 w-4" />Générer avec l'IA</>
                  }
                </button>
                {parsedData != null && !generating && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                    Préparation prête — pensez à sauvegarder
                  </div>
                )}
              </div>
            </form>
          </Form>
        </div>
      </div>

      {/* Result */}
      {(generating || parsedData) && (
        <div className="space-y-4">
          {/* Result header */}
          <div className="flex items-center justify-between flex-wrap gap-3 pb-1">
            <div className="flex items-center gap-3 flex-wrap">
              <h2 className="text-xl font-bold text-foreground">Préparation générée</h2>
              {lastForm && (
                <>
                  <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full border" style={{ background: currentSeq.bg, borderColor: currentSeq.border, color: currentSeq.color }}>
                    {currentSeq.label}
                  </span>
                  <span className="text-xs text-muted-foreground capitalize">{watchAge}</span>
                </>
              )}
            </div>
            {parsedData != null && !generating && (
              <button
                onClick={handleSave}
                disabled={createLesson.isPending}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm text-white transition-all disabled:opacity-60 shadow-sm hover:shadow-md active:scale-95"
                style={{ background: "hsl(220 55% 28%)" }}
                data-testid="button-save"
              >
                <Save className="h-4 w-4" />
                {createLesson.isPending ? "Sauvegarde..." : "Sauvegarder"}
              </button>
            )}
          </div>

          {generationError !== "" && (
            <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-4 text-destructive text-sm">{generationError}</div>
          )}

          {generating && parsedData == null && (
            <div className="bg-card border border-border rounded-xl p-8 flex flex-col items-center gap-3 text-muted-foreground">
              <RefreshCw className="h-8 w-8 animate-spin" style={{ color: "hsl(220 55% 30%)" }} />
              <div className="text-center">
                <p className="font-medium text-foreground">L'IA prépare votre leçon…</p>
                <p className="text-xs mt-1">Cela peut prendre 15 à 30 secondes</p>
              </div>
            </div>
          )}

          {parsedData != null && lastForm != null && renderContent(parseInt(lastForm.sequence), parsedData)}
        </div>
      )}
    </div>
  );
}
